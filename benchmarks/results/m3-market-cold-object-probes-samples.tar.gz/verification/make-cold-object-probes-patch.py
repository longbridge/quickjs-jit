from pathlib import Path
import re,difflib
old=Path('/tmp/inactive-probes-after.c').read_text()
pattern=r'(?m)^( +)(qjsjit_record_(?:callsite|property)_feedback\(rt, b,[\s\S]*?;)$'
def wrap(m):
 indent=m[1]
 return indent+'if (qjsjit_feedback_enabled(rt, b)) {\n'+indent+'    '+m[2].replace('\n','\n    ')+'\n'+indent+'}'
s,n=re.subn(pattern,wrap,old);assert n==5,n
patch='diff --git a/quickjs.c b/quickjs.c\n'+''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/quickjs.c',tofile='b/quickjs.c'))
Path('/tmp/cold-object-probes-after.c').write_text(s);Path('sys/patches/0015-cold-object-probes.patch').write_text(patch)
def fnv(s):
 h=0xcbf29ce484222325
 for b in s.encode():h=((h^b)*0x100000001b3)&0xffffffffffffffff
 return h
p=Path('sys/build_support/patch.rs');t=p.read_text().replace('EXPECTED_PATCHES: [(&str, u64); 14]','EXPECTED_PATCHES: [(&str, u64); 15]');t=re.sub(r'    \("0015-cold-object-probes.patch", 0x[0-9a-f]+\),\n','',t);t=re.sub(r'(    \("0014-inactive-probes.patch", 0x[0-9a-f]+\),)',lambda m:m[1]+f'\n    ("0015-cold-object-probes.patch", 0x{fnv(patch):016x}),',t);t=re.sub(r'("quickjs.c", )0x[0-9a-f]+',lambda m:m[1]+f'0x{fnv(s):016x}',t);p.write_text(t)
p=Path('sys/tests/jit_patch.rs');t=p.read_text().replace('        "0015-cold-object-probes.patch",\n','').replace('        "0014-inactive-probes.patch",','        "0014-inactive-probes.patch",\n        "0015-cold-object-probes.patch",');p.write_text(t)
