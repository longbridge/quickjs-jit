"""Complete the final scenario after CRLF left a CR in the first command's name."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.path.insert(0, '/evidence/tools')
from protocol_check import validate_protocol

root = Path('/evidence/refresh-feedback-2738ec7')
metadata_path = root / 'metadata.json'
original_text = metadata_path.read_text()
original = json.loads(original_text)
assert original['status'] == 'collecting'
assert len(original['scripts']) == 35 and 'refresh-feedback' not in original['scripts']
assert original['command'][original['command'].index('--workloads') + 1].endswith('refresh-feedback\r')
assert not (root / 'failure.json').exists()
assert not any(root.glob('refresh-feedback-*.json'))
assert len(list(root.glob('*-automatic.json'))) == 35 * 35 * 2
assert len(list(root.glob('*-interpreter.json'))) == 35 * 35 * 2
assert len(list(root.glob('*-bun.json'))) == 35 * 35
(root / 'segment-1-metadata.json').write_text(original_text)
command = [sys.executable, '-u', '/evidence/tools/paired.py',
           '--binaries', '/evidence/binaries.json', '--scripts', '/src/benchmarks/scripts',
           '--workloads', 'refresh-feedback', '--output', '/evidence/refresh-feedback-final-case',
           '--cpu', '2', '--pairs', '30']
subprocess.run(command, check=True)
last = Path('/evidence/refresh-feedback-final-case')
last_text = (last / 'metadata.json').read_text()
final = json.loads(last_text)
assert final['status'] == 'complete' and list(final['scripts']) == ['refresh-feedback']
for key in ['pairs', 'discarded_processes', 'cpu', 'binary_sha256', 'binaries', 'configs',
            'collector_sha256', 'cpu_description', 'governor', 'platform', 'bun_path',
            'bun_version', 'bun_sha256', 'bun_flags', 'rustc', 'protocol', 'timed_batches',
            'throughput_windows']:
    assert original[key] == final[key], key
(root / 'segment-2-metadata.json').write_text(last_text)
samples = list(last.glob('refresh-feedback-*.json'))
assert len(samples) == 175
for sample in samples:
    assert not (root / sample.name).exists()
    shutil.copyfile(sample, root / sample.name)
original['scripts'].update(final['scripts'])
note = ('The first invocation completed all 35 original scenarios, then failed before starting '
        'refresh-feedback because CRLF in workloads.txt left a trailing CR in that name. '
        'The final scenario was collected separately with identical collector, CPU affinity, '
        'protocol, binary and engine hashes. Both original metadata files are retained; '
        'no samples were discarded or replaced. The combined metadata is validated below.')
original['collection_segments'] = ['segment-1-metadata.json', 'segment-2-metadata.json']
original['collection_note'] = note
for workload in original['scripts']:
    checksums, drivers = set(), set()
    for pair in range(-5, 30):
        for variant, mode in original['configs']:
            sample = json.loads((root / f'{workload}-{pair}-{variant}-{mode}.json').read_text())
            assert (sample['pair_index'], sample['variant'], sample['requested_mode']) == (pair, variant, mode)
            validate_protocol(sample, original, workload, mode)
            checksums.add(sample['checksum'])
            drivers.add(sample['protocol']['driver_sha256'])
    assert len(checksums) == len(drivers) == 1, workload
original['status'] = 'complete'
metadata_path.write_text(json.dumps(original, indent=2) + '\n')
manifest_path = root.parent / 'source-manifest.json'
manifest = json.loads(manifest_path.read_text())
manifest['collection_note'] = note
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
subprocess.run([sys.executable, '-u', '/evidence/tools/summarize_paired.py', str(root)], check=True)
subprocess.run([sys.executable, '/inputs/write_matrix.py', str(root)], check=True)
print('Completed and validated all 6,300 samples across 36 scenarios.', flush=True)
