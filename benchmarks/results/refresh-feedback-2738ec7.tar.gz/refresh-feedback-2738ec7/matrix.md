**Complete 36-scenario Linux x86_64 matrix, completed 2026-10-24 UTC: automatic baseline refresh feedback.**

The candidate runtime is `2738ec70b80f6d1c3ea086422000eb32b15b42a3`; the previous JIT is `96593cd7a54440ac060a391b8baea7e9a3cf1393`. Both binaries use the benchmark harness and scripts from `6d1f9d8f9a18f3cbe60102f713f89ae419e2ae12`. QuickJS is the candidate binary with the JIT detached; Bun uses its default configuration.

Host: AMD Ryzen 7 9800X3D, Docker Desktop/WSL2 Linux x86_64 on Windows, Rust 1.99.0, Bun 1.4.4, CPU 2 affinity; the Docker VM exposes four CPUs and 7.76 GiB memory. CPU governor/power policy was not recorded. This is Linux container evidence, not a native-Windows performance result.

`shared-js-multibatch-v3`: five discarded and 30 retained fresh processes per configuration, one initial call, 64 ten-call warmup batches and 16 timed ten-call batches. Configurations interleave in alternating order. Timings below are medians in milliseconds per ten calls; speed ratios are paired geometric means with 95% bootstrap confidence intervals (10,000 resamples, seed 20260909). All slower, fallback-only and inconclusive cases are retained.

Collection ran in two sequential segments: the 35 original scenarios, then `refresh-feedback` separately after correcting a CRLF workload-list argument. Both segments used identical engine/collector hashes and settings; all 6,300 samples and both original metadata files are retained.

Against the previous automatic JIT, four scenarios are significantly faster, one is slower and 31 are statistically tied. The slower `float64-dense` result is 0.907x the previous speed (95% CI 0.811–0.99983x); the unchanged interpreter control is tied (1.001x, 0.964–1.039x). The new `refresh-feedback` scenario is also tied with the previous JIT (1.009x, between 6.30% slower and 8.16% faster). The allocation reduction is established by the runtime regression, not by a JavaScript latency improvement in that scenario.

| Workload | QuickJS ms | Bun ms | quickjs-jit ms | vs QuickJS speed [95% CI] | vs Bun speed [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| scalar-control-flow | 1.362400 | 0.013699 | 0.064626 | 21.436x [20.401, 22.779] (faster) | 0.212x [0.199, 0.227] (slower) |
| scalar-expressions | 1.079694 | 0.010951 | 0.061799 | 17.478x [16.694, 18.290] (faster) | 0.185x [0.173, 0.201] (slower) |
| host-compute | 1.649031 | 0.015523 | 0.080805 | 20.841x [19.505, 22.397] (faster) | 0.211x [0.187, 0.238] (slower) |
| mixed-quotes | 2.281624 | 0.068882 | 1.028603 | 2.196x [2.122, 2.272] (faster) | 0.075x [0.068, 0.083] (slower) |
| quickjs-int-arith | 3.217098 | 0.042477 | 0.330445 | 8.886x [8.111, 9.727] (faster) | 0.122x [0.113, 0.132] (slower) |
| quickjs-bitops | 0.422658 | 0.013881 | 0.031795 | 11.856x [10.663, 13.162] (faster) | 0.369x [0.340, 0.400] (slower) |
| quickjs-fibonacci | 0.920666 | 0.005843 | 0.516305 | 1.785x [1.721, 1.849] (faster) | 0.014x [0.012, 0.016] (slower) |
| numeric | 0.483964 | 0.005584 | 0.035884 | 13.897x [12.890, 14.915] (faster) | 0.170x [0.154, 0.191] (slower) |
| scalar-loop | 0.482224 | 0.005607 | 0.035786 | 13.360x [12.124, 14.450] (faster) | 0.162x [0.143, 0.183] (slower) |
| call-heavy | 1.274550 | 0.014283 | 0.054917 | 23.769x [22.976, 24.726] (faster) | 0.244x [0.218, 0.275] (slower) |
| generic-call-entry | 1.042806 | 0.009780 | 0.040128 | 25.986x [25.424, 26.571] (faster) | 0.240x [0.212, 0.274] (slower) |
| generic-call-fallback | 1.470147 | 0.011017 | 0.365341 | 3.942x [3.804, 4.069] (faster) | 0.037x [0.032, 0.044] (slower) |
| property-heavy | 1.302618 | 0.009518 | 0.045374 | 27.956x [26.336, 29.330] (faster) | 0.211x [0.198, 0.224] (slower) |
| fibonacci-iterative | 46.659396 | 0.240191 | 1.301886 | 34.919x [33.232, 36.629] (faster) | 0.183x [0.167, 0.202] (slower) |
| fibonacci-recursive | 14.528095 | 0.394390 | 0.625269 | 21.410x [19.528, 23.377] (faster) | 0.656x [0.609, 0.710] (slower) |
| collections | 1.773319 | 0.091400 | 1.828048 | 0.974x [0.960, 0.989] (slower) | 0.054x [0.050, 0.058] (slower) |
| for-of-array | 0.660262 | 0.041333 | 0.686559 | 0.956x [0.938, 0.973] (slower) | 0.050x [0.043, 0.058] (slower) |
| strings-json | 2.817991 | 0.219073 | 2.858068 | 1.005x [0.973, 1.047] (statistically tied; between 2.70% slower and 4.73% faster) | 0.080x [0.073, 0.087] (slower) |
| calls-closures | 7.347697 | 0.115339 | 8.035768 | 0.867x [0.748, 1.007] (statistically tied; between 25.19% slower and 0.73% faster) | 0.015x [0.013, 0.018] (slower) |
| adversarial | 0.828531 | 0.048307 | 0.865722 | 0.962x [0.943, 0.981] (slower) | 0.058x [0.055, 0.062] (slower) |
| float64-dense | 2.860400 | 0.066830 | 0.194267 | 13.701x [12.407, 14.918] (faster) | 0.328x [0.295, 0.364] (slower) |
| strings-regexp | 20.473885 | 1.315794 | 22.175191 | 1.045x [0.938, 1.190] (statistically tied; between 6.15% slower and 18.97% faster) | 0.062x [0.057, 0.068] (slower) |
| arrays-typed | 4.288814 | 0.061940 | 1.788450 | 2.433x [2.241, 2.667] (faster) | 0.034x [0.032, 0.037] (slower) |
| packed-array-traversal | 0.755151 | 0.008266 | 0.044297 | 18.208x [16.770, 19.815] (faster) | 0.252x [0.206, 0.310] (slower) |
| int32array-traversal | 1.232408 | 0.007681 | 0.043889 | 28.786x [26.556, 31.320] (faster) | 0.205x [0.179, 0.235] (slower) |
| float64array-traversal | 1.864812 | 0.011938 | 0.089537 | 23.094x [20.858, 25.593] (faster) | 0.155x [0.143, 0.169] (slower) |
| typed-convert-traversal | 1.802623 | 0.030979 | 0.071993 | 25.442x [23.511, 27.534] (faster) | 0.353x [0.271, 0.459] (slower) |
| objects-polymorphic | 8.919831 | 0.173505 | 7.880637 | 1.076x [0.984, 1.180] (statistically tied; between 1.56% slower and 18.01% faster) | 0.020x [0.018, 0.023] (slower) |
| property-polymorphic | 1.543913 | 0.037732 | 0.909762 | 1.776x [1.666, 1.893] (faster) | 0.038x [0.035, 0.042] (slower) |
| calls-recursion-closures | 5.097047 | 0.190418 | 5.633302 | 0.910x [0.835, 0.988] (slower) | 0.030x [0.026, 0.034] (slower) |
| json-codec | 101.932316 | 6.312822 | 96.385822 | 0.989x [0.910, 1.068] (statistically tied; between 8.96% slower and 6.77% faster) | 0.065x [0.059, 0.071] (slower) |
| map-set-bigint | 20.198242 | 1.015994 | 19.984519 | 1.042x [0.929, 1.180] (statistically tied; between 7.12% slower and 18.03% faster) | 0.050x [0.045, 0.056] (slower) |
| exceptions-promises-async | 2.739075 | 0.162122 | 2.989110 | 0.886x [0.793, 0.974] (slower) | 0.051x [0.045, 0.058] (slower) |
| methods-dynamic | 13.666536 | 0.155741 | 14.142783 | 0.954x [0.899, 1.010] (statistically tied; between 10.09% slower and 0.97% faster) | 0.011x [0.010, 0.012] (slower) |
| exceptions-sync | 1.621857 | 0.126339 | 1.682019 | 0.983x [0.941, 1.030] (statistically tied; between 5.94% slower and 3.05% faster) | 0.080x [0.075, 0.086] (slower) |
| refresh-feedback | 1.387461 | 0.015947 | 1.159004 | 1.177x [1.101, 1.253] (faster) | 0.014x [0.013, 0.016] (slower) |

<details><summary>Previous-JIT comparison, interpreter control and native-entry diagnostics</summary>

| Workload | Previous JIT ms | Candidate / previous JIT speed [95% CI] | Candidate / previous interpreter speed [95% CI] | Fixed-batch native entries | Quiet timed windows / 30 |
| --- | ---: | --- | --- | --- | ---: |
| scalar-control-flow | 0.065935 | 1.109x [0.99719, 1.244] (statistically tied; between 0.28% slower and 24.43% faster) | 0.986x [0.956, 1.018] (statistically tied; between 4.37% slower and 1.80% faster) | [10, 20] | 27 |
| scalar-expressions | 0.063145 | 1.035x [0.981, 1.089] (statistically tied; between 1.88% slower and 8.95% faster) | 0.994x [0.978, 1.010] (statistically tied; between 2.24% slower and 1.03% faster) | [10, 20] | 24 |
| host-compute | 0.082900 | 1.027x [0.933, 1.133] (statistically tied; between 6.75% slower and 13.31% faster) | 1.026x [0.988, 1.074] (statistically tied; between 1.16% slower and 7.39% faster) | [10, 20] | 24 |
| mixed-quotes | 1.029410 | 0.986x [0.943, 1.027] (statistically tied; between 5.73% slower and 2.74% faster) | 1.020x [0.99530, 1.048] (statistically tied; between 0.47% slower and 4.76% faster) | [6990, 6990] | 30 |
| quickjs-int-arith | 0.361969 | 1.024x [0.954, 1.098] (statistically tied; between 4.64% slower and 9.79% faster) | 1.010x [0.919, 1.113] (statistically tied; between 8.13% slower and 11.26% faster) | [20, 20] | 30 |
| quickjs-bitops | 0.034519 | 0.99563x [0.904, 1.098] (statistically tied; between 9.58% slower and 9.81% faster) | 0.950x [0.855, 1.055] (statistically tied; between 14.55% slower and 5.55% faster) | [20, 20] | 30 |
| quickjs-fibonacci | 0.508161 | 0.988x [0.948, 1.026] (statistically tied; between 5.18% slower and 2.65% faster) | 0.99595x [0.964, 1.030] (statistically tied; between 3.57% slower and 2.97% faster) | [20, 20] | 30 |
| numeric | 0.035525 | 1.049x [0.959, 1.172] (statistically tied; between 4.06% slower and 17.21% faster) | 1.006x [0.967, 1.050] (statistically tied; between 3.28% slower and 5.02% faster) | [10, 20] | 18 |
| scalar-loop | 0.035901 | 1.026x [0.910, 1.139] (statistically tied; between 9.03% slower and 13.89% faster) | 1.00007x [0.976, 1.023] (statistically tied; between 2.44% slower and 2.28% faster) | [10, 20] | 18 |
| call-heavy | 0.056557 | 1.075x [1.025, 1.137] (faster) | 1.008x [0.973, 1.043] (statistically tied; between 2.67% slower and 4.33% faster) | [10, 10] | 26 |
| generic-call-entry | 0.041957 | 1.077x [1.032, 1.135] (faster) | 0.995x [0.984, 1.006] (statistically tied; between 1.57% slower and 0.57% faster) | [10, 10] | 22 |
| generic-call-fallback | 0.368616 | 1.038x [0.981, 1.100] (statistically tied; between 1.85% slower and 10.00% faster) | 1.00162x [0.989, 1.015] (statistically tied; between 1.10% slower and 1.46% faster) | [10, 10] | 30 |
| property-heavy | 0.045825 | 1.009x [0.950, 1.073] (statistically tied; between 5.03% slower and 7.29% faster) | 0.987x [0.970, 1.00435] (statistically tied; between 2.96% slower and 0.43% faster) | [10, 10] | 23 |
| fibonacci-iterative | 1.315818 | 1.013x [0.99551, 1.032] (statistically tied; between 0.45% slower and 3.19% faster) | 0.99521x [0.967, 1.026] (statistically tied; between 3.32% slower and 2.63% faster) | [20, 20] | 30 |
| fibonacci-recursive | 0.612483 | 0.958x [0.909, 1.00293] (statistically tied; between 9.13% slower and 0.29% faster) | 1.034x [0.993, 1.079] (statistically tied; between 0.70% slower and 7.91% faster) | [20, 20] | 30 |
| collections | 1.828217 | 0.990x [0.976, 1.00253] (statistically tied; between 2.44% slower and 0.25% faster) | 0.99554x [0.982, 1.009] (statistically tied; between 1.84% slower and 0.92% faster) | [10, 10] | 30 |
| for-of-array | 0.680080 | 0.991x [0.976, 1.006] (statistically tied; between 2.43% slower and 0.64% faster) | 1.012x [0.992, 1.032] (statistically tied; between 0.83% slower and 3.20% faster) | [10, 10] | 30 |
| strings-json | 2.900710 | 1.039x [1.014, 1.071] (faster) | 0.970x [0.931, 1.00198] (statistically tied; between 6.88% slower and 0.20% faster) | [10, 10] | 30 |
| calls-closures | 8.120237 | 0.966x [0.841, 1.107] (statistically tied; between 15.91% slower and 10.68% faster) | 1.00124x [0.873, 1.150] (statistically tied; between 12.72% slower and 14.97% faster) | [10, 10] | 30 |
| adversarial | 0.856332 | 0.989x [0.975, 1.00334] (statistically tied; between 2.53% slower and 0.33% faster) | 0.99593x [0.978, 1.014] (statistically tied; between 2.21% slower and 1.41% faster) | [10, 10] | 30 |
| float64-dense | 0.187810 | 0.907x [0.811, 0.99983] (slower) | 1.00119x [0.964, 1.039] (statistically tied; between 3.59% slower and 3.91% faster) | [20, 20] | 14 |
| strings-regexp | 22.294431 | 1.103x [1.011, 1.209] (faster) | 0.950x [0.852, 1.042] (statistically tied; between 14.77% slower and 4.19% faster) | [10, 10] | 30 |
| arrays-typed | 1.875887 | 1.00397x [0.948, 1.064] (statistically tied; between 5.15% slower and 6.36% faster) | 0.974x [0.912, 1.040] (statistically tied; between 8.84% slower and 4.03% faster) | [30, 30] | 30 |
| packed-array-traversal | 0.042783 | 0.975x [0.877, 1.084] (statistically tied; between 12.32% slower and 8.38% faster) | 1.031x [0.959, 1.107] (statistically tied; between 4.13% slower and 10.69% faster) | [10, 10] | 24 |
| int32array-traversal | 0.043921 | 1.00150x [0.884, 1.148] (statistically tied; between 11.62% slower and 14.80% faster) | 0.985x [0.923, 1.046] (statistically tied; between 7.75% slower and 4.62% faster) | [10, 10] | 28 |
| float64array-traversal | 0.087906 | 0.988x [0.889, 1.103] (statistically tied; between 11.11% slower and 10.26% faster) | 1.007x [0.951, 1.072] (statistically tied; between 4.95% slower and 7.23% faster) | [10, 10] | 30 |
| typed-convert-traversal | 0.064887 | 1.00278x [0.914, 1.100] (statistically tied; between 8.60% slower and 9.98% faster) | 1.00219x [0.932, 1.078] (statistically tied; between 6.77% slower and 7.76% faster) | [10, 10] | 22 |
| objects-polymorphic | 8.254532 | 0.992x [0.905, 1.092] (statistically tied; between 9.51% slower and 9.20% faster) | 1.084x [0.992, 1.182] (statistically tied; between 0.77% slower and 18.24% faster) | [20, 20] | 30 |
| property-polymorphic | 0.854637 | 0.986x [0.927, 1.041] (statistically tied; between 7.27% slower and 4.12% faster) | 0.981x [0.929, 1.036] (statistically tied; between 7.07% slower and 3.62% faster) | [10, 10] | 30 |
| calls-recursion-closures | 6.267563 | 1.095x [0.979, 1.245] (statistically tied; between 2.11% slower and 24.53% faster) | 1.014x [0.944, 1.088] (statistically tied; between 5.57% slower and 8.76% faster) | [10, 10] | 30 |
| json-codec | 97.740652 | 0.995x [0.939, 1.055] (statistically tied; between 6.10% slower and 5.52% faster) | 1.005x [0.946, 1.068] (statistically tied; between 5.38% slower and 6.82% faster) | [10, 10] | 30 |
| map-set-bigint | 20.396532 | 1.00193x [0.899, 1.116] (statistically tied; between 10.07% slower and 11.61% faster) | 0.978x [0.886, 1.081] (statistically tied; between 11.43% slower and 8.07% faster) | [10, 10] | 30 |
| exceptions-promises-async | 2.970299 | 0.920x [0.828, 1.007] (statistically tied; between 17.23% slower and 0.69% faster) | 0.966x [0.907, 1.026] (statistically tied; between 9.27% slower and 2.56% faster) | [10, 10] | 30 |
| methods-dynamic | 14.748375 | 1.030x [0.958, 1.103] (statistically tied; between 4.19% slower and 10.27% faster) | 0.99587x [0.953, 1.040] (statistically tied; between 4.69% slower and 4.02% faster) | [10, 10] | 30 |
| exceptions-sync | 1.691105 | 1.012x [0.955, 1.074] (statistically tied; between 4.51% slower and 7.37% faster) | 0.958x [0.904, 1.014] (statistically tied; between 9.56% slower and 1.41% faster) | [10, 10] | 30 |
| refresh-feedback | 1.169976 | 1.009x [0.937, 1.082] (statistically tied; between 6.30% slower and 8.16% faster) | 1.066x [1.00037, 1.142] (faster) | [0, 0] | 30 |

</details>

`refresh-feedback` keeps 16 object-building functions alive and calls them through the same array of functions in every engine. Definitions are outside the timed region. The runtime allocation regression separately measures ten cold refresh candidates with 20/200 unrelated call signatures: the previous implementation allocates 1,213/12,013 times; the candidate allocates 3/3 times.

Native-entry ranges cover the first timed batch and aggregate the shared driver and workload; they do not identify a particular function or establish a steady native tier. QuickJS includes one outer Rust call per batch. Checksums run outside the measured regions. No JavaScript throughput, GPUI snapshot/render speed, or resolution of a long-running application hang is inferred from these kernel timings.

[Raw samples, source and binary hashes, Cargo.lock and collector metadata](benchmarks/results/refresh-feedback-2738ec7.tar.gz); [all summaries](benchmarks/results/refresh-feedback-2738ec7.json).

A separate 30-pair `float64-dense` repeat used the same binaries, collector, CPU affinity and warmup/timing protocol. Candidate speed relative to the previous JIT was 0.985x [0.935, 1.034] (statistically tied; between 6.48% slower and 3.37% faster); the unchanged interpreter control was 0.973x [0.909, 1.031] (statistically tied; between 9.09% slower and 3.10% faster). Both runs are retained in the raw archive; the repeat does not replace the matrix result.
