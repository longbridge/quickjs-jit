import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/evidence/refresh-feedback-2738ec7')
metadata = json.loads((root / 'metadata.json').read_text())
source = json.loads(Path('/evidence/source-manifest.json').read_text())
assert metadata['status'] == 'complete'
assert metadata['pairs'] == 30 and metadata['discarded_processes'] == 5
assert len(metadata['scripts']) == 36
assert metadata['timed_batches'] == 16 and metadata['throughput_windows'] == 0
assert len(metadata['configs']) == 5
assert len(list(root.glob('*-automatic.json'))) == 36 * 35 * 2
assert len(list(root.glob('*-interpreter.json'))) == 36 * 35 * 2
assert len(list(root.glob('*-bun.json'))) == 36 * 35
for variant, binary in metadata['binaries'].items():
    assert hashlib.sha256(Path(binary).read_bytes()).hexdigest() == metadata['binary_sha256'][variant]
for relative, digest in source['harness_sha256'].items():
    assert hashlib.sha256((Path('/src') / relative).read_bytes()).hexdigest() == digest, relative
assert hashlib.sha256(Path('/src/jit/src/lib.rs').read_bytes()).hexdigest() == source['candidate_runtime_source_sha256']
assert hashlib.sha256(Path('/evidence/Cargo.lock').read_bytes()).hexdigest() == source['cargo_lock_sha256']
for filename in ['source-manifest.json', 'Cargo.lock', 'allocation-regression.json', 'Dockerfile']:
    shutil.copyfile(Path('/evidence') / filename, root / filename)
shutil.copytree('/evidence/tools', root / 'collector', dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__', 'sampling.lock'))
shutil.copytree('/src/benchmarks/scripts', root / 'scripts', dirs_exist_ok=True)
shutil.copyfile('/src/benchmarks/batch-driver.js', root / 'batch-driver.js')
repeat = Path('/evidence/float64-dense-repeat')
repeat_metadata = json.loads((repeat / 'metadata.json').read_text())
assert repeat_metadata['status'] == 'complete' and list(repeat_metadata['scripts']) == ['float64-dense']
for key in ['pairs', 'discarded_processes', 'cpu', 'binary_sha256', 'configs', 'collector_sha256',
            'bun_sha256', 'bun_flags', 'rustc', 'protocol', 'timed_batches', 'throughput_windows']:
    assert metadata[key] == repeat_metadata[key], key
shutil.copytree(repeat, root / 'float64-dense-repeat', dirs_exist_ok=True)
for filename in ['write_matrix.py', 'finish_collection.py', 'collect.sh', 'package_evidence.py']:
    shutil.copyfile(Path('/inputs') / filename, root / filename)
subprocess.run(['python3', '/inputs/write_matrix.py', str(root)], check=True)
with tarfile.open('/evidence/refresh-feedback-2738ec7.tar.gz', 'w:gz') as archive:
    archive.add(root, arcname=root.name)
print(json.dumps({'archive_bytes': Path('/evidence/refresh-feedback-2738ec7.tar.gz').stat().st_size,
                  'raw_samples': 36 * 35 * 5, 'summary_rows': len(json.loads((root / 'summary.json').read_text()))}))
