set -eu
mkdir -p /evidence/tools
cp /src/benchmarks/paired.py /src/benchmarks/protocol_check.py /src/benchmarks/summarize_paired.py /evidence/tools/
cp /inputs/source-manifest.json /inputs/allocation-regression.json /inputs/Dockerfile /inputs/binaries.json /inputs/workloads.txt /evidence/
cp /src/Cargo.lock /evidence/Cargo.lock
python3 -u /evidence/tools/paired.py --binaries /evidence/binaries.json --scripts /src/benchmarks/scripts --workloads "$(cat /evidence/workloads.txt)" --output /evidence/refresh-feedback-2738ec7 --cpu 2 --pairs 30
python3 -u /evidence/tools/summarize_paired.py /evidence/refresh-feedback-2738ec7
python3 /inputs/write_matrix.py /evidence/refresh-feedback-2738ec7
