import json
from pathlib import Path
import sys
from datetime import datetime, timezone

root = Path(sys.argv[1])
metadata = json.loads((root / "metadata.json").read_text())
source = json.loads((root.parent / "source-manifest.json").read_text())
rows = json.loads((root / "summary.json").read_text())
assert metadata["status"] == "complete" and metadata["pairs"] == 30
assert len(metadata["scripts"]) == 36
data = {(r["workload"], r["variant"], r["mode"]): r for r in rows}

def value(workload, variant, mode):
    return data[workload, variant, mode]

def milliseconds(row):
    return f'{row["median_ns"] / 1_000_000:.6f}'

def ratio(item, with_interval=False):
    speed = item["speed"]
    lo, hi = item["ci95"]
    assert 0 < lo <= hi and speed > 0
    number = lambda x: f'{x:.5f}' if abs(x - 1) < 0.005 else f'{x:.3f}'
    if lo > 1:
        label = "faster"
    elif hi < 1:
        label = "slower"
    else:
        label = f'statistically tied; between {(1-lo)*100:.2f}% slower and {(hi-1)*100:.2f}% faster'
    interval = f' [{number(lo)}, {number(hi)}]' if with_interval else ""
    return f'{number(speed)}x{interval} ({label})'

lines = [
    f'**Complete 36-scenario Linux x86_64 matrix, completed {datetime.now(timezone.utc).date()} UTC: automatic baseline refresh feedback.**',
    '',
    f'The candidate runtime is `{source["candidate_runtime_revision"]}`; the previous JIT is '
    f'`{source["baseline_revision"]}`. Both binaries use the benchmark harness and scripts from '
    f'`{source["benchmark_revision"]}`. '
    'QuickJS is the candidate binary with the JIT detached; Bun uses its default configuration.',
    '',
    f'Host: AMD Ryzen 7 9800X3D, Docker Desktop/WSL2 Linux x86_64 on Windows, Rust 1.99.0, Bun {metadata["bun_version"]}, '
    f'CPU {metadata["cpu"]} affinity; the Docker VM exposes four CPUs and 7.76 GiB memory. CPU governor/power policy '
    'was not recorded. This is Linux container evidence, not a native-Windows performance result.',
    '',
    '`shared-js-multibatch-v3`: five discarded and 30 retained fresh processes per configuration, '
    'one initial call, 64 ten-call warmup batches and 16 timed ten-call batches. Configurations '
    'interleave in alternating order. Timings below are medians in milliseconds per ten calls; '
    'speed ratios are paired geometric means with 95% bootstrap confidence intervals '
    '(10,000 resamples, seed 20260909). All slower, fallback-only and inconclusive cases are retained.',
    '',
    'Collection ran in two sequential segments: the 35 original scenarios, then '
    '`refresh-feedback` separately after correcting a CRLF workload-list argument. '
    'Both segments used identical engine/collector hashes and settings; all 6,300 samples '
    'and both original metadata files are retained.',
    '',
    'Against the previous automatic JIT, four scenarios are significantly faster, '
    'one is slower and 31 are statistically tied. The slower `float64-dense` result '
    'is 0.907x the previous speed (95% CI 0.811–0.99983x); the unchanged interpreter '
    'control is tied (1.001x, 0.964–1.039x). The new `refresh-feedback` scenario is '
    'also tied with the previous JIT (1.009x, between 6.30% slower and 8.16% faster). '
    'The allocation reduction is established by the runtime regression, not by '
    'a JavaScript latency improvement in that scenario.',
    '',
    '| Workload | QuickJS ms | Bun ms | quickjs-jit ms | vs QuickJS speed [95% CI] | vs Bun speed [95% CI] |',
    '| --- | ---: | ---: | ---: | --- | --- |',
]
for name in metadata["scripts"]:
    candidate = value(name, "candidate", "automatic")
    interpreter = value(name, "candidate", "interpreter")
    bun = value(name, "baseline", "bun")
    lines.append(f'| {name} | {milliseconds(interpreter)} | {milliseconds(bun)} | '
                 f'{milliseconds(candidate)} | {ratio(candidate["comparisons"]["candidate/interpreter"], True)} | '
                 f'{ratio(candidate["comparisons"]["baseline/bun"], True)} |')
lines += [
    '',
    '<details><summary>Previous-JIT comparison, interpreter control and native-entry diagnostics</summary>',
    '',
    '| Workload | Previous JIT ms | Candidate / previous JIT speed [95% CI] | Candidate / previous interpreter speed [95% CI] | Fixed-batch native entries | Quiet timed windows / 30 |',
    '| --- | ---: | --- | --- | --- | ---: |',
]
for name in metadata["scripts"]:
    candidate = value(name, "candidate", "automatic")
    baseline = value(name, "baseline", "automatic")
    interpreter = value(name, "candidate", "interpreter")
    lines.append(f'| {name} | {milliseconds(baseline)} | '
                 f'{ratio(candidate["comparisons"]["baseline/automatic"], True)} | '
                 f'{ratio(interpreter["comparisons"]["baseline/interpreter"], True)} | '
                 f'{candidate["native_entry_range"]} | {candidate["compilation_quiet_samples"]} |')
lines += [
    '',
    '</details>',
    '',
    '`refresh-feedback` keeps 16 object-building functions alive and calls them through the same '
    'array of functions in every engine. Definitions are outside the timed region. The runtime '
    'allocation regression separately measures ten cold refresh candidates with 20/200 unrelated '
    'call signatures: the previous implementation allocates 1,213/12,013 times; the candidate '
    'allocates 3/3 times.',
    '',
    'Native-entry ranges cover the first timed batch and aggregate the shared driver and workload; '
    'they do not identify a particular function or establish a steady native tier. QuickJS includes '
    'one outer Rust call per batch. Checksums run outside the measured regions. No JavaScript '
    'throughput, GPUI snapshot/render speed, or resolution of a long-running application hang '
    'is inferred from these kernel timings.',
    '',
    '[Raw samples, source and binary hashes, Cargo.lock and collector metadata]'
    '(benchmarks/results/refresh-feedback-2738ec7.tar.gz); '
    '[all summaries](benchmarks/results/refresh-feedback-2738ec7.json).',
]
repeat_rows = json.loads((root.parent / 'float64-dense-repeat/summary.json').read_text())
repeat_candidate = next(r for r in repeat_rows if r['variant'] == 'candidate' and r['mode'] == 'automatic')
repeat_control = next(r for r in repeat_rows if r['variant'] == 'candidate' and r['mode'] == 'interpreter')
lines += [
    '',
    'A separate 30-pair `float64-dense` repeat used the same binaries, collector, CPU affinity '
    'and warmup/timing protocol. Candidate speed relative to the previous JIT was '
    + ratio(repeat_candidate['comparisons']['baseline/automatic'], True)
    + '; the unchanged interpreter control was '
    + ratio(repeat_control['comparisons']['baseline/interpreter'], True)
    + '. Both runs are retained in the raw archive; the repeat does not replace the matrix result.',
]
(root / "matrix.md").write_text("\n".join(lines) + "\n")
print(json.dumps({"matrix": str(root / "matrix.md"), "rows": len(metadata["scripts"])}))
