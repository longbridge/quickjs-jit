//! Explicit scalar values used by production numeric value numbering.
//!
//! Values currently cross expression boundaries inside a basic block. Block
//! inputs remain distinct until CFG Phi construction proves their identity.
//! Numeric operations retain JavaScript number semantics; selecting Int32 or
//! Float64 and checking overflow still belongs to feedback-guided lowering.

use std::collections::BTreeMap;

use super::{FrameSlot, OptimizedBlock, OptimizedEffect, OptimizedNode, OptimizedNodeKind};
use crate::compiler::CompileFailure;

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct ScalarValueId(u32);

impl ScalarValueId {
    pub const fn index(self) -> usize {
        self.0 as usize
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum ScalarBinaryOp {
    Add,
    Sub,
    Mul,
    Div,
}

impl ScalarBinaryOp {
    fn from_opcode(name: &str) -> Option<Self> {
        match name {
            "add" => Some(Self::Add),
            "sub" => Some(Self::Sub),
            "mul" => Some(Self::Mul),
            "div" => Some(Self::Div),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ScalarValue {
    Int32(i32),
    Input {
        block_pc: u32,
        slot: FrameSlot,
    },
    Binary {
        op: ScalarBinaryOp,
        lhs: ScalarValueId,
        rhs: ScalarValueId,
    },
    /// A producer whose value identity is known, but whose semantics have not
    /// yet been modeled by this pass. Never value-number opaque operations.
    Opaque,
}

#[derive(Clone, Debug, Default)]
pub struct ScalarGraph {
    values: Vec<ScalarValue>,
    node_values: Vec<Option<ScalarValueId>>,
    value_limit: usize,
}

impl ScalarGraph {
    pub fn values(&self) -> &[ScalarValue] {
        &self.values
    }

    pub fn value_for_node(&self, node: u32) -> Option<ScalarValueId> {
        self.node_values.get(node as usize).copied().flatten()
    }

    pub fn allocated_bytes(&self) -> usize {
        self.values.capacity() * core::mem::size_of::<ScalarValue>()
            + self.node_values.capacity() * core::mem::size_of::<Option<ScalarValueId>>()
    }

    fn push(&mut self, value: ScalarValue) -> Result<ScalarValueId, CompileFailure> {
        if self.values.len() >= self.value_limit {
            return Err(CompileFailure::ResourceLimit);
        }
        let id = u32::try_from(self.values.len()).map_err(|_| CompileFailure::ResourceLimit)?;
        self.values.push(value);
        Ok(ScalarValueId(id))
    }

    pub(super) fn rewrite(
        nodes: &mut [OptimizedNode],
        blocks: &[OptimizedBlock],
    ) -> Result<(Self, u64), CompileFailure> {
        let mut graph = Self {
            values: Vec::new(),
            node_values: vec![None; nodes.len()],
            // Block-input stacks can otherwise grow quadratically in CFGs
            // with many joins. Bound the pass independently of lowering.
            value_limit: nodes.len().saturating_mul(4),
        };
        let mut eliminated = 0;
        for block in blocks {
            let mut frame = BTreeMap::<(u8, u16), ScalarValueId>::new();
            let mut expressions = BTreeMap::new();
            let mut constants = BTreeMap::<i32, ScalarValueId>::new();
            let mut stack = Vec::new();
            for index in 0..block.stack_depth() {
                stack.push(graph.push(ScalarValue::Input {
                    block_pc: block.start_pc(),
                    slot: FrameSlot::Stack(index),
                })?);
            }
            for &id in block.nodes() {
                let node = &mut nodes[id as usize];
                let base = stack
                    .len()
                    .checked_sub(usize::from(node.pops()))
                    .ok_or(CompileFailure::InvalidArtifact)?;
                if node.eliminated() {
                    stack.truncate(base);
                    for _ in 0..node.pushes() {
                        stack.push(graph.push(ScalarValue::Opaque)?);
                    }
                    continue;
                }
                let result = match node.kind() {
                    OptimizedNodeKind::Reuse { source } => Some(
                        graph
                            .value_for_node(*source)
                            .ok_or(CompileFailure::InvalidArtifact)?,
                    ),
                    OptimizedNodeKind::Bytecode { opcode } => {
                        if let Some(constant) = integer_constant(opcode, node.bytes()) {
                            let value = if let Some(value) = constants.get(&constant) {
                                *value
                            } else {
                                let value = graph.push(ScalarValue::Int32(constant))?;
                                constants.insert(constant, value);
                                value
                            };
                            Some(value)
                        } else if super::optimized::is_pure_load(opcode) {
                            let index =
                                super::optimized::indexed_node_operand(opcode, node.bytes())
                                    .ok_or(CompileFailure::InvalidArtifact)?;
                            let argument = opcode.starts_with("get_arg");
                            let key = (u8::from(!argument), index);
                            let value = if let Some(value) = frame.get(&key) {
                                *value
                            } else {
                                let value = graph.push(ScalarValue::Input {
                                    block_pc: block.start_pc(),
                                    slot: if argument {
                                        FrameSlot::Argument(index)
                                    } else {
                                        FrameSlot::Local(index)
                                    },
                                })?;
                                frame.insert(key, value);
                                value
                            };
                            Some(value)
                        } else if let Some(op) = ScalarBinaryOp::from_opcode(opcode) {
                            if node.pops() != 2 || node.pushes() != 1 {
                                return Err(CompileFailure::InvalidArtifact);
                            }
                            let lhs = stack[base];
                            let rhs = stack[base + 1];
                            let key = (op, lhs, rhs, node.representation() as u8);
                            if let Some(&(value, source)) = expressions.get(&key) {
                                // Keep the original operand consumption. The
                                // backend's SSA DCE removes now-unused loads;
                                // no adjacency or single-use assumption is made.
                                node.reuse_value(source);
                                eliminated += 1;
                                Some(value)
                            } else {
                                let value = graph.push(ScalarValue::Binary { op, lhs, rhs })?;
                                expressions.insert(key, (value, id));
                                Some(value)
                            }
                        } else {
                            None
                        }
                    }
                    OptimizedNodeKind::GuardNumeric { .. } => None,
                };
                if node.effect() != OptimizedEffect::Pure {
                    // Do not carry speculation across calls, polls, frame
                    // writes or other effects until the clobber model proves
                    // those operations preserve both values and guards.
                    expressions.clear();
                    if node.effect() == OptimizedEffect::FrameWrite {
                        if let Some(slot) = super::optimized::frame_write_slot(node) {
                            frame.remove(&slot);
                        } else {
                            frame.clear();
                        }
                    } else {
                        frame.clear();
                    }
                }
                stack.truncate(base);
                for output in 0..node.pushes() {
                    let value = if output == 0 {
                        match result {
                            Some(value) => value,
                            None => graph.push(ScalarValue::Opaque)?,
                        }
                    } else {
                        graph.push(ScalarValue::Opaque)?
                    };
                    stack.push(value);
                    if node.pushes() == 1 {
                        graph.node_values[id as usize] = Some(value);
                    }
                }
            }
        }
        Ok((graph, eliminated))
    }
}

fn integer_constant(name: &str, bytes: &[u8]) -> Option<i32> {
    match name {
        "push_minus1" => Some(-1),
        "push_0" | "push_1" | "push_2" | "push_3" | "push_4" | "push_5" | "push_6" | "push_7" => {
            Some(i32::from(name.as_bytes()[5] - b'0'))
        }
        "push_i8" => Some(i32::from(*bytes.get(1)? as i8)),
        "push_i16" => Some(i32::from(i16::from_le_bytes(
            bytes.get(1..3)?.try_into().ok()?,
        ))),
        "push_i32" => Some(i32::from_le_bytes(bytes.get(1..5)?.try_into().ok()?)),
        _ => None,
    }
}
