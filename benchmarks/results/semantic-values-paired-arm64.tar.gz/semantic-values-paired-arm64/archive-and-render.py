from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path.cwd(); out=Path(Path('/tmp/quickjs-semantic-values-path').read_text()); paired=out/'paired'
meta=json.loads((paired/'metadata.json').read_text()); assert meta['status']=='complete'
rows=json.loads((paired/'summary.json').read_text()); assert len(rows)==130
for name,expected in meta['scripts'].items():
 assert hashlib.sha256((out/'source/benchmarks/scripts'/f'{name}.js').read_bytes()).hexdigest()==expected
stem='semantic-values-paired-arm64'
summary=root/'benchmarks/results'/f'{stem}.json'; shutil.copy2(paired/'summary.json',summary)
stage=out/'evidence';stage.mkdir(exist_ok=False)
for name in ['paired','source']:
 shutil.copytree(out/name,stage/name)
shutil.copy2(Path(__file__),stage/'archive-and-render.py')
for name in ['sources.json','baseline-sources.json','source.diff','binaries.json','workloads.txt','collection.log']:
 shutil.copy2(out/name,stage/name)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hashes={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
archive=root/'benchmarks/results'/f'{stem}.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname=stem)
with tarfile.open(archive,'r:gz') as tar:
 for name,h in hashes.items():assert hashlib.sha256(tar.extractfile(f'{stem}/{name}').read()).hexdigest()==h
manifest={'runtime_base':'023a2206d20d3cc8aa1646f3ab7fa0ad34fb220d','candidate_source':'archived source.diff plus source/jit/src/ir/scalar.rs','quickjs':'0.15.1 (same source, candidate binary with JIT detached)','metadata':meta,'archive':str(archive.relative_to(root)),'archive_sha256':sha(archive),'summary_sha256':sha(summary),'verified_archived_files':len(hashes)}
(root/'benchmarks/results'/f'{stem}-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def speed(v):
 value=v['speed'];lo,hi=v['ci95'];s=f'{value:.4f}x [{lo:.4f}, {hi:.4f}]'
 if lo<=1<=hi:s+=f'; statistically tied ({(1-lo)*100:.2f}% slower to {(hi-1)*100:.2f}% faster)'
 return s
by={(r['workload'],r['variant'],r['mode']):r for r in rows}
text='''<!-- BEGIN JIT_MATRIX -->

**Complete 26-scenario macOS matrix, 2026-09-10: numeric semantic values.**
This candidate adds explicit intra-block numeric operands and nested expression
reuse to `023a220`; the immutable pre-change `023a220` binary is the regression
control. The archived source diff and new scalar module identify the measured
candidate. CFG Phi, exact SSA FrameState, inlining, property and array passes
remain unfinished; this table is evidence for the first numeric step.

Timings are medians in **ms per ten workload calls**. Ratios are paired geometric
means of reference latency / candidate latency, with 95% confidence intervals;
values above 1x are faster. QuickJS 0.15.1 runs with JIT detached in the candidate
binary; quickjs-jit uses production automatic tiering. Bun 1.4.0 uses default
flags. Every row, including fallback-only and slower results, is retained.

| Workload | Previous JIT ms | QuickJS ms | Bun ms | quickjs-jit ms | JIT / previous speed [95% CI] | JIT / QuickJS speed [95% CI] | JIT / Bun speed [95% CI] |
| --- | ---: | ---: | ---: | ---: | --- | --- | --- |
'''
for w in meta['scripts']:
 r=by[w,'candidate','automatic']; old=by[w,'baseline','automatic'];q=by[w,'candidate','interpreter'];b=by[w,'baseline','bun'];c=r['comparisons']
 text+=f"| {w} | {old['median_ns']/1e6:.6f} | {q['median_ns']/1e6:.6f} | {b['median_ns']/1e6:.6f} | {r['median_ns']/1e6:.6f} | {speed(c['baseline/automatic'])} | {speed(c['candidate/interpreter'])} | {speed(c['baseline/bun'])} |\n"
text+='''
Protocol `shared-js-fixed-warmup-v2`: one initial call, 64 ten-call warmup
batches, then one timed ten-call batch, with result consumption/checksum outside
timing. All engines use identical scripts, inputs and driver. Each workload has
five discarded and 30 retained fresh processes in each of five configurations
(previous/current automatic, previous/current interpreter, default Bun), with
alternating reversed order. All 4,550 process records are archived. Bootstrap:
10,000 paired percentile resamples, seed 20260909, sorted indices 249/9749.

Apple M3, macOS ARM64 / Darwin 27.0.0; Rust 1.98.1 / LLVM 22.1.8;
release build, no CPU pinning, power policy not recorded. `host-compute` measures
the equivalent pure-JS render kernel, excluding GPUI allocation and snapshots.
No Linux, host reload or throughput result is inferred from these timings.

Automatic native coverage is reported without conditioning the timing samples:

| Workload | Fixed-batch native entries (min–max) | Compilation quiet samples / 30 |
| --- | ---: | ---: |
'''
for w in meta['scripts']:
 r=by[w,'candidate','automatic'];bounds=r['native_entry_range'];text+=f"| {w} | {bounds[0]}–{bounds[1]} | {r['compilation_quiet_samples']} |\n"
text+=f'''
[All raw records and source/build inputs](benchmarks/results/{stem}.tar.gz),
[all configuration comparisons](benchmarks/results/{stem}.json),
[verified hashes and machine provenance](benchmarks/results/{stem}-manifest.json),
and [remaining architecture and performance gates](docs/SEMANTIC_SSA_PROGRESS.md).

<!-- END JIT_MATRIX -->

'''
p=root/'README.md';s=p.read_text();s=s.replace('<!-- BEGIN JIT_MATRIX -->','<!-- BEGIN HISTORICAL_JIT_MATRIX -->',1).replace('<!-- END JIT_MATRIX -->','<!-- END HISTORICAL_JIT_MATRIX -->',1)
s=s.replace('<!-- BEGIN HISTORICAL_JIT_MATRIX -->',text+'<!-- BEGIN HISTORICAL_JIT_MATRIX -->',1).replace('**Complete 24-scenario matrix: candidate4, measured 2026-09-10.**','**Historical Linux 24-scenario matrix: candidate4, measured 2026-09-10.**').replace('A refreshed complete 25-scenario matrix and native\nLinux host regression acceptance remain pending.','The complete current macOS matrix is above; native Linux host regression\nacceptance remains deferred.');s=s.replace('**Focused baseline comparison, 2026-09-10', '**Historical focused baseline comparison, 2026-09-10').replace('No runtime code\nchanged in this baseline work.', 'That baseline comparison did not change runtime code.')
p.write_text(s)
print(archive); print('verified files',len(hashes))
for w in ['scalar-expressions','generic-call-entry','generic-call-fallback','property-heavy','arrays-typed']:
 r=by[w,'candidate','automatic']; print(w, r['comparisons'])
