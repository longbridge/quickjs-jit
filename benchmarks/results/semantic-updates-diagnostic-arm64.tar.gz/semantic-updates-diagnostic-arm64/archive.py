from pathlib import Path
import json,hashlib,shutil,tarfile
root=Path.cwd(); out=Path(Path('/tmp/quickjs-semantic-updates-path').read_text()); raw=out/'diagnostic'
meta=json.loads((raw/'metadata.json').read_text()); rows=json.loads((raw/'summary.json').read_text()); comparisons=json.loads((raw/'comparisons.json').read_text())
assert meta['status']=='complete' and len(rows)==36 and len(comparisons)==6
records=[p for p in raw.glob('*.json') if p.name not in ['metadata.json','summary.json','comparisons.json']]
assert len(records)==540
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((out/'sources.json').read_text())
for name,expected in sources['source_files'].items(): assert sha(out/'source'/name)==expected,name
for variant,path in meta['binaries'].items(): assert sha(Path(path))==meta['binary_sha256'][variant]==sources['binary_sha256'][variant]
stem='semantic-updates-diagnostic-arm64'; stage=out/'diagnostic-evidence'; stage.mkdir()
for name in ['source','diagnostic']: shutil.copytree(out/name,stage/name)
for name in ['sources.json','baseline-sources.json','previous-cfg-sources.json','source.diff','binaries.json','diagnostic-command.json','diagnostic.log','diagnostic-summary.log','runtime-tests.log','clippy.log','build.log']:
    shutil.copy2(out/name,stage/name)
shutil.copy2(Path(__file__),stage/'archive.py')
hashes={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
archive=root/'benchmarks/results'/f'{stem}.tar.gz'; assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar: tar.add(stage,arcname=stem)
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in hashes.items(): assert hashlib.sha256(tar.extractfile(f'{stem}/{name}').read()).hexdigest()==expected,name
summary=root/'benchmarks/results'/f'{stem}.json'; shutil.copy2(raw/'summary.json',summary)
manifest=dict(status='focused diagnostic only; full matrix pending; no-regression gate unmet',metadata=meta,sources=sources,comparisons=comparisons,process_records=len(records),verified_files=len(hashes),archive_sha256=sha(archive),summary_sha256=sha(summary))
(root/'benchmarks/results'/f'{stem}-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
by={(r['workload'],r['variant'],r['mode']):r for r in rows}
def speed(c):
    lo,hi=c['ci95']; s=f"{c['speed']:.4f}x [{lo:.4f}, {hi:.4f}]"
    if lo<=1<=hi:s+=f'; statistically tied ({100*(1-lo):.2f}% slower to {100*(hi-1):.2f}% faster)'
    return s
text='\n## Focused update diagnostic, 2026-09-10\n\nAll 540 process records passed collector/summarizer validation. Six scenarios,\nsix configurations, five discarded and ten retained fresh-process pairs use\nthe same fixed-warmup protocol as the full matrix. This smaller diagnostic\nis not a replacement for the pending full matrix. All timings below are median\nms per ten calls; ratios are paired geometric speed with 95% bootstrap intervals.\n\n| Scenario | Pre-SSA ms | Prior CFG ms | QuickJS ms | Bun ms | New JIT ms | New / pre-SSA speed | New / prior CFG speed | New / QuickJS speed | New / Bun speed |\n| --- | ---: | ---: | ---: | ---: | ---: | --- | --- | --- | --- |\n'
for c in comparisons:
    w=c['workload']; times=[by[w,v,m]['median_ns']/1e6 for v,m in [('baseline','automatic'),('previous_cfg','automatic'),('candidate','interpreter'),('baseline','bun'),('candidate','automatic')]]
    text+='| '+w+' | '+' | '.join(f'{t:.6f}' for t in times)+' | '+' | '.join(speed(c[k]) for k in ['baseline','previous_cfg','QuickJS','Bun'])+' |\n'
text+='\nAll candidate samples had ten native entries and quiet compilation. Numeric,\nscalar-loop, iterative Fibonacci and scalar-control-flow remain significantly\nslower than the pre-SSA baseline in this diagnostic. The first three recover\npart of the prior CFG loss, but none passes the no-regression gate. Host-compute\nis tied with baseline; scalar expressions improves over baseline. The complete\n27-scenario README matrix remains the previous frozen CFG run.\n\nThe strengthened ARM64 sum-loop test also passes with at most three 64-bit\ncomparisons (two entry tags and the poll budget), so repeated tag comparisons\nare insufficient to explain the remaining slowdown. Next inspect invariant\nargument Phi cycles and register moves rather than assuming another tag check.\n\nEvidence: `benchmarks/results/'+stem+'.tar.gz`, summary JSON and manifest.\n'
with (root/'docs/SEMANTIC_SSA_PROGRESS.md').open('a') as f:f.write(text)
print(json.dumps(dict(archive=str(archive),verified_files=len(hashes),records=len(records))))
