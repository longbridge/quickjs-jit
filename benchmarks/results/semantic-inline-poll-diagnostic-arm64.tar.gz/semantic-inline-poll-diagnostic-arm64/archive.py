from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path.cwd(); out=Path(Path('/tmp/quickjs-semantic-inline-poll-path').read_text()); raw=out/'diagnostic'
meta=json.loads((raw/'metadata.json').read_text());rows=json.loads((raw/'summary.json').read_text());sources=json.loads((out/'sources.json').read_text())
assert meta['status']=='complete' and len(rows)==36
records=list(raw.glob('*.json'));assert len(records)==542
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in sources['source_files'].items():assert sha(out/'source'/n)==h
for v,p in meta['binaries'].items():assert sha(Path(p))==meta['binary_sha256'][v]
stem='semantic-inline-poll-diagnostic-arm64';stage=out/'diagnostic-evidence';stage.mkdir()
for n in ['source','diagnostic']:shutil.copytree(out/n,stage/n)
for n in ['sources.json','source.diff','binaries.json','baseline-sources.json','previous-inline-sources.json','diagnostic-command.json','summarize-diagnostic.py','runtime-tests.log','clippy.log','build.log']:shutil.copy2(out/n,stage/n)
shutil.copy2('/tmp/inline-poll-diagnostic.log',stage/'collector.log');shutil.copy2('/tmp/inline-poll-summary.log',stage/'summary.log');shutil.copy2(__file__,stage/'archive.py')
hashes={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()};(stage/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
archive=root/'benchmarks/results'/f'{stem}.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:t.add(stage,arcname=stem)
with tarfile.open(archive,'r:gz') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(f'{stem}/{n}').read()).hexdigest()==h
summary=root/'benchmarks/results'/f'{stem}.json';shutil.copy2(raw/'summary.json',summary)
manifest=dict(status='six-scenario diagnostic only; full matrix and acceptance pending',metadata=meta,sources=sources,process_records=540,verified_files=len(hashes),archive_sha256=sha(archive),summary_sha256=sha(summary))
(root/'benchmarks/results'/f'{stem}-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
by={(r['workload'],r['variant'],r['mode']):r for r in rows}
def fmt(c):
 lo,hi=c['ci95'];return f"{c['speed']:.4f}x [{lo:.4f}, {hi:.4f}]"+(f"; statistically tied ({100*(1-lo):.2f}% slower to {100*(hi-1):.2f}% faster)" if lo<=1<=hi else '')
text='\n### Poll diagnostic: all six scenarios\n\n540 process records, six configurations, five discarded and ten retained pairs.\nMedian ms per ten calls; paired geometric speeds with 95% bootstrap CIs.\n\n| Scenario | Previous inline ms | QuickJS ms | Bun ms | Candidate ms | Previous speed | QuickJS speed | Bun speed |\n| --- | ---: | ---: | ---: | ---: | --- | --- | --- |\n'
for w in meta['scripts']:
 r=by[w,'candidate','automatic'];times=[by[w,v,m]['median_ns']/1e6 for v,m in [('previous_inline','automatic'),('candidate','interpreter'),('baseline','bun'),('candidate','automatic')]];c=r['comparisons'];text+='| '+w+' | '+' | '.join(f'{x:.6f}' for x in times)+' | '+' | '.join(fmt(c[k]) for k in ['previous_inline/automatic','candidate/interpreter','baseline/bun'])+' |\n'
text+='\nAll candidate samples were compilation-quiet. Call-heavy and generic-call-entry\nimprove, but scalar-loop and arrays-typed are slower than the previous inline\ncandidate. This is not acceptance or a substitute for the full 27-scenario\nREADME matrix. Evidence: `benchmarks/results/'+stem+'.tar.gz` and matching JSON/manifest.\n'
with (root/'docs/SEMANTIC_SSA_PROGRESS.md').open('a') as f:f.write(text)
print(json.dumps(dict(records=540,verified_files=len(hashes),archive=str(archive))))
