from pathlib import Path
import json,random,statistics
r=Path('/tmp/quickjs-market-measurements');p=r/'tail2000-summary.json';s=json.loads(p.read_text())
s.update(schema='gpui-tail2000-acceptance-v1',baseline_revision='a64e9a6',renders_per_process=2000,limitations=['Snapshot construction and validation, not FPS.','Upstream diagnostic build script copies ambient JIT sources as provenance only; upstream binary uses registry rquickjs 0.12.2 and does not link those JIT sources.'])
for w,v in s['summary'].items():
 data={m:[json.loads((r/'tail2000-samples'/f'{w}-{m}-{i}.json').read_text()) for i in range(30)] for m in ['upstream','candidate_auto','interpreter']}
 for m,group in data.items():
  assert all(len(x['render_samples_ns'])==2000 for x in group)
  v[m]['hot_reload_ns']=statistics.median(x['hot_reload_ns'] for x in group)
  v[m]['installed_before_after']=[(x['installed_before_measurement'],x['installed']) for x in group]
 for metric in ['steady_state_ns','first_window_ns','p99_script_render_ns','hot_reload_ns']:
  for base in ['upstream','interpreter']:
   x=[data[base][i][metric]/data['candidate_auto'][i][metric] for i in range(30)];rng=random.Random(42);b=sorted(statistics.median(rng.choices(x,k=30)) for _ in range(10000));v[metric+'_speed_vs_'+base]={'paired_median':statistics.median(x),'bootstrap_95_ci':[b[249],b[9749]]}
 print(w,{k:v[k] for k in v if k.endswith('_speed_vs_upstream')})
p.write_text(json.dumps(s,indent=2)+'\n')
