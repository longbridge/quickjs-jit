from pathlib import Path
import json, subprocess, os, hashlib, statistics, random
root=Path('/tmp/quickjs-market-measurements')
binaries={'upstream':root/'upstream-tail2000','candidate_auto':root/'tail2000','interpreter':root/'tail2000'}
samples=root/'tail2000-samples';samples.mkdir(exist_ok=True)
host_cpu_start=subprocess.check_output(['ps','-axo','pcpu,comm'],text=True)
for workload in ['mixed','compute','panel']:
 for pair in range(-5,30):
  modes=list(binaries)
  if pair % 2: modes.reverse()
  for mode in modes:
   path=samples/f'{workload}-{mode}-{pair}.json'
   env=dict(os.environ,GPUI_SHELL_JIT_SAMPLE=str(path),GPUI_SHELL_JIT_MODE='interpreter' if mode in ['interpreter','baseline_interpreter','upstream'] else 'automatic',GPUI_SHELL_JIT_PAIR=str(max(pair,0)),GPUI_SHELL_JIT_WORKLOAD=workload)
   p=subprocess.run([str(binaries[mode]),'tests::benchmark::emit_one_jit_acceptance_sample','--exact'],env=env,capture_output=True,text=True)
   if p.returncode:
    path.with_suffix('.log').write_text(p.stdout+p.stderr);raise SystemExit(f'failed {path}')
  if (pair+1)%5==0: print(f'{workload}: {pair+1}/30',flush=True)
summary={}
host_cpu_end=subprocess.check_output(['ps','-axo','pcpu,comm'],text=True)

for workload in ['mixed','compute','panel']:
 data={mode:[json.loads((samples/f'{workload}-{mode}-{i}.json').read_text()) for i in range(30)] for mode in binaries}
 checksums={x['checksum'] for group in data.values() for x in group}
 assert len(checksums)==1,(workload,checksums)
 result={}
 for mode,group in data.items():
  result[mode]={k:statistics.median(x[k] for x in group) for k in ['steady_state_ns','p99_script_render_ns','first_window_ns']}
  for k in ['fallback_count','invalid_artifacts','native_entries','deopts']:
   result[mode][k]={'min':min(x[k] for x in group),'max':max(x[k] for x in group),'nonzero_samples':sum(x[k]>0 for x in group)}
 for baseline in ['upstream','interpreter']:
  ratios=[data[baseline][i]['steady_state_ns']/data['candidate_auto'][i]['steady_state_ns'] for i in range(30)]
  rng=random.Random(42)
  draws=sorted(statistics.median(rng.choices(ratios,k=30)) for _ in range(10000))
  result['candidate_speed_vs_'+baseline]={'paired_median':statistics.median(ratios),'bootstrap_95_ci':[draws[249],draws[9749]]}
 summary[workload]=result
metadata={'host_cpu_start':host_cpu_start,'host_cpu_end':host_cpu_end,'schema':'gpui-borrowed-property-paired-v1','baseline_revision':'9a83a7f9cdc178a0ab5d7b29c3c9227b0dcb8620 + bounded-deopt and runtime lookup patches (feedback-cache)','warmup_processes':5,'measured_processes':30,'metric':'snapshot construction and validation, ns','binaries':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in binaries.items()},'summary':summary}
(root/'tail2000-summary.json').write_text(json.dumps(metadata,indent=2))
print(json.dumps(summary,indent=2),flush=True)
