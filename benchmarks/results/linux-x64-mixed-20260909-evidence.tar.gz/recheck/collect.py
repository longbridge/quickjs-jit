import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).parent
PREVIOUS = Path('/tmp/quickjs-rebench-20260909')
SAMPLES = ROOT / 'samples'
SAMPLES.mkdir(exist_ok=True)
metadata = json.loads((PREVIOUS / 'metadata.json').read_text())
for version in ('baseline', 'candidate'):
    assert hashlib.sha256((PREVIOUS / version).read_bytes()).hexdigest() == metadata['binary_sha256'][version]

for pair in range(-5, 30):
    versions = ['baseline', 'candidate']
    if pair % 2:
        versions.reverse()
    for version in versions:
        modes = ['interpreter', 'automatic']
        if pair % 2:
            modes.reverse()
        for mode in modes:
            env = dict(os.environ, GPUI_SHELL_JIT_SAMPLE=str(SAMPLES / f'{pair}-mixed-{version}-{mode}.json'), GPUI_SHELL_JIT_MODE=mode, GPUI_SHELL_JIT_PAIR=str(pair + 5), GPUI_SHELL_JIT_WORKLOAD='mixed')
            subprocess.run(['taskset', '-c', '2', str(PREVIOUS / version), 'tests::benchmark::emit_one_jit_acceptance_sample', '--exact'], env=env, check=True, stdout=subprocess.DEVNULL)
    print(f'recheck pair {pair}', flush=True)

for pair in range(30):
    for version in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
        experiment = ROOT / f'{version}-{pair}.er'
        env = dict(os.environ, GPUI_SHELL_JIT_SAMPLE=str(ROOT / f'profile-{version}-{pair}.json'), GPUI_SHELL_JIT_MODE='automatic', GPUI_SHELL_JIT_PAIR=str(pair), GPUI_SHELL_JIT_WORKLOAD='mixed')
        with (ROOT / f'profile-{version}-{pair}.log').open('w') as log:
            subprocess.run(['taskset', '-c', '2', 'gprofng', 'collect', 'app', '-p', '0.5', '-a', 'off', '-o', str(experiment), str(PREVIOUS / version), 'tests::benchmark::emit_one_jit_acceptance_sample', '--exact'], env=env, check=True, stdout=log, stderr=subprocess.STDOUT)
    print(f'profile pair {pair}', flush=True)

for version in ('baseline', 'candidate'):
    with (ROOT / f'{version}-profile.txt').open('w') as report:
        subprocess.run(['gprofng', 'display', 'text', '-limit', '0', '-functions', *[str(ROOT / f'{version}-{pair}.er') for pair in range(30)]], stdout=report, stderr=subprocess.STDOUT, check=True)
