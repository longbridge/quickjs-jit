import json
import math
from pathlib import Path
import random
import statistics

ROOT = Path(__file__).parent
rng = random.Random(20260909)
data = {}
for version in ('baseline', 'candidate'):
    for mode in ('interpreter', 'automatic'):
        values = [json.loads((ROOT / 'samples' / f'{i}-mixed-{version}-{mode}.json').read_text()) for i in range(30)]
        for i, value in enumerate(values):
            assert value['pair_index'] == i + 5
            assert value['workload'] == 'mixed' and value['mode'] == mode
            assert value['native_enabled'] == (mode == 'automatic')
            assert value['native_entries'] == value['native_exits']
            assert value['deopts'] == value['fallback_count'] == 0
            assert value['script_renders'] == 270
        data[version, mode] = values
assert len({v['checksum'] for values in data.values() for v in values}) == 1
assert len({v['snapshot_sha256'] for values in data.values() for v in values}) == 1
rows = []
for label, before, after in (
    ('new/old JIT', ('baseline', 'automatic'), ('candidate', 'automatic')),
    ('new/old interpreter', ('baseline', 'interpreter'), ('candidate', 'interpreter')),
    ('new JIT/interpreter', ('candidate', 'interpreter'), ('candidate', 'automatic')),
):
    for metric in ('steady_state_ns', 'p99_script_render_ns', 'first_window_ns', 'hot_reload_ns'):
        a, b = data[before], data[after]
        logs = [math.log(x[metric] / y[metric]) for x, y in zip(a, b)]
        draws = sorted(math.exp(statistics.mean(rng.choices(logs, k=30))) for _ in range(10000))
        rows.append(dict(comparison=label, metric=metric,
            baseline_ms=statistics.median(x[metric] for x in a) / 1e6,
            candidate_ms=statistics.median(x[metric] for x in b) / 1e6,
            speed=math.exp(statistics.mean(logs)), ci95=[draws[249], draws[9749]]))
counters = {f'{version}/{mode}': {key: [min(v[key] for v in values), max(v[key] for v in values)]
    for key in ('native_entries', 'installed', 'compile_failures', 'invalid_artifacts', 'deopts', 'fallback_count')}
    for (version, mode), values in data.items()}
result = dict(validated_samples=120, checksum=next(iter(data.values()))[0]['checksum'], comparisons=rows, counters=counters)
(ROOT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
