import json,random,statistics,math
from pathlib import Path
P=Path(__file__).parent
S=P/'samples'
rng=random.Random(20260909)
def ci(ratios):
    logs=[math.log(x) for x in ratios]; n=len(logs)
    draws=sorted(math.exp(sum(rng.choices(logs,k=n))/n) for _ in range(10000))
    return math.exp(statistics.mean(logs)),draws[249],draws[9749]
rows=[]
for workload in ['panel','compute','mixed']:
    data={(v,m):[json.loads((S/f'{i}-{workload}-{v}-{m}.json').read_text()) for i in range(30)] for v in ['baseline','candidate'] for m in ['interpreter','automatic']}
    assert len({x['checksum'] for values in data.values() for x in values})==1,workload
    for label,a,b in [('new/old JIT',('baseline','automatic'),('candidate','automatic')),('new/old interpreter',('baseline','interpreter'),('candidate','interpreter')),('new JIT/interpreter',('candidate','interpreter'),('candidate','automatic'))]:
        for metric in ['steady_state_ns','p99_script_render_ns','first_window_ns','hot_reload_ns']:
            ratios=[x[metric]/y[metric] for x,y in zip(data[a],data[b])]
            speed,lo,hi=ci(ratios)
            rows.append(dict(workload=workload,comparison=label,metric=metric,baseline_ms=statistics.median(x[metric] for x in data[a])/1e6,candidate_ms=statistics.median(x[metric] for x in data[b])/1e6,speed=speed,ci95=[lo,hi]))
    for key,values in data.items():
        print(workload,key,{k:[min(x[k] for x in values),max(x[k] for x in values)] for k in ['native_entries','fallback_count','deopts','invalid_artifacts','compile_failures']})
(P/'summary.json').write_text(json.dumps(rows,indent=2))
lines=['# QuickJS-JIT GPUI Shell performance retest — 2026-09-09','','Baseline: crates.io 0.12.6. Candidate: upstream main `07535b14bf290c65f052bff19c49b89b316c0914` (post-v0.12.7).','','Host: Intel Core i7-13700KF, Linux x86_64, release build, CPU 2 affinity. Same GPUI Shell source and test harness for both versions; only five QuickJS packages replaced via temporary Cargo patch configuration.','','30 interleaved independent process pairs per workload and mode, after 5 warmup process pairs; 64 warmup renders and 200 timed renders per process. Timings include snapshot construction and debug-tree validation, not frame rendering or FPS. Medians shown in milliseconds; speed is the geometric mean of paired latency ratios with 95% paired bootstrap intervals (10,000 resamples). Shared desktop host, CPU not exclusively reserved.','','All measured snapshots match across versions and modes. Raw samples and binary hashes accompany this report.','','| Workload | Comparison | Metric | Baseline ms | Candidate ms | Speed | 95% interval |','|---|---|---|---:|---:|---:|---|']
for r in rows:
    lo,hi=r['ci95']; tied=' (statistically tied)' if lo<=1<=hi else ''
    lines.append(f"| {r['workload']} | {r['comparison']} | {r['metric']} | {r['baseline_ms']:.4f} | {r['candidate_ms']:.4f} | {r['speed']:.3f}x | {lo:.3f}–{hi:.3f}x{tied} |")
(P/'report.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
