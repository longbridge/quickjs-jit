# QuickJS-JIT GPUI Shell performance retest — 2026-09-09

Baseline: crates.io 0.12.6. Candidate: upstream main `07535b14bf290c65f052bff19c49b89b316c0914` (post-v0.12.7).

Host: Intel Core i7-13700KF, Linux x86_64, release build, CPU 2 affinity. Same GPUI Shell source and test harness for both versions; only five QuickJS packages replaced via temporary Cargo patch configuration.

30 interleaved independent process pairs per workload and mode, after 5 warmup process pairs; 64 warmup renders and 200 timed renders per process. Timings include snapshot construction and debug-tree validation, not frame rendering or FPS. Medians shown in milliseconds; speed is the geometric mean of paired latency ratios with 95% paired bootstrap intervals (10,000 resamples). Shared desktop host, CPU not exclusively reserved.

All measured snapshots match across versions and modes. Raw samples and binary hashes accompany this report.

| Workload | Comparison | Metric | Baseline ms | Candidate ms | Speed | 95% interval |
|---|---|---|---:|---:|---:|---|
| panel | new/old JIT | steady_state_ns | 0.8182 | 0.8185 | 0.996x | 0.989–1.001x (statistically tied) |
| panel | new/old JIT | p99_script_render_ns | 0.8383 | 0.8365 | 0.991x | 0.956–1.014x (statistically tied) |
| panel | new/old JIT | first_window_ns | 5.4383 | 5.3619 | 1.011x | 1.005–1.017x |
| panel | new/old JIT | hot_reload_ns | 0.6855 | 0.6896 | 0.995x | 0.988–1.003x (statistically tied) |
| panel | new/old interpreter | steady_state_ns | 0.8096 | 0.8132 | 0.998x | 0.993–1.004x (statistically tied) |
| panel | new/old interpreter | p99_script_render_ns | 0.8319 | 0.8330 | 1.000x | 0.995–1.007x (statistically tied) |
| panel | new/old interpreter | first_window_ns | 5.3471 | 5.3602 | 1.001x | 0.993–1.010x (statistically tied) |
| panel | new/old interpreter | hot_reload_ns | 0.6853 | 0.6863 | 1.000x | 0.993–1.009x (statistically tied) |
| panel | new JIT/interpreter | steady_state_ns | 0.8132 | 0.8185 | 0.991x | 0.983–0.995x |
| panel | new JIT/interpreter | p99_script_render_ns | 0.8330 | 0.8365 | 0.980x | 0.949–0.997x |
| panel | new JIT/interpreter | first_window_ns | 5.3602 | 5.3619 | 0.997x | 0.991–1.004x (statistically tied) |
| panel | new JIT/interpreter | hot_reload_ns | 0.6863 | 0.6896 | 0.994x | 0.988–1.000x |
| compute | new/old JIT | steady_state_ns | 0.0124 | 0.0119 | 1.080x | 0.952–1.225x (statistically tied) |
| compute | new/old JIT | p99_script_render_ns | 0.0147 | 0.0152 | 1.085x | 0.785–1.458x (statistically tied) |
| compute | new/old JIT | first_window_ns | 4.8849 | 4.7678 | 1.025x | 1.019–1.031x |
| compute | new/old JIT | hot_reload_ns | 0.2489 | 0.2042 | 1.215x | 1.202–1.227x |
| compute | new/old interpreter | steady_state_ns | 0.2302 | 0.1821 | 1.263x | 1.260–1.267x |
| compute | new/old interpreter | p99_script_render_ns | 0.2422 | 0.1969 | 1.233x | 1.224–1.244x |
| compute | new/old interpreter | first_window_ns | 4.7902 | 4.7288 | 1.014x | 1.007–1.020x |
| compute | new/old interpreter | hot_reload_ns | 0.2510 | 0.2026 | 1.236x | 1.225–1.247x |
| compute | new JIT/interpreter | steady_state_ns | 0.1821 | 0.0119 | 13.367x | 12.048–14.687x |
| compute | new JIT/interpreter | p99_script_render_ns | 0.1969 | 0.0152 | 10.580x | 8.029–12.993x |
| compute | new JIT/interpreter | first_window_ns | 4.7288 | 4.7678 | 0.992x | 0.982–1.002x (statistically tied) |
| compute | new JIT/interpreter | hot_reload_ns | 0.2026 | 0.2042 | 0.991x | 0.982–0.998x |
| mixed | new/old JIT | steady_state_ns | 0.1365 | 0.1940 | 0.701x | 0.698–0.704x |
| mixed | new/old JIT | p99_script_render_ns | 0.1537 | 0.2002 | 0.739x | 0.705–0.767x |
| mixed | new/old JIT | first_window_ns | 4.9806 | 4.9206 | 1.008x | 1.002–1.014x |
| mixed | new/old JIT | hot_reload_ns | 0.3558 | 0.3037 | 1.170x | 1.161–1.179x |
| mixed | new/old interpreter | steady_state_ns | 0.3190 | 0.2653 | 1.202x | 1.199–1.204x |
| mixed | new/old interpreter | p99_script_render_ns | 0.3457 | 0.2756 | 1.231x | 1.190–1.261x |
| mixed | new/old interpreter | first_window_ns | 4.9665 | 4.8264 | 1.027x | 1.021–1.034x |
| mixed | new/old interpreter | hot_reload_ns | 0.3569 | 0.3011 | 1.182x | 1.173–1.191x |
| mixed | new JIT/interpreter | steady_state_ns | 0.2653 | 0.1940 | 1.368x | 1.364–1.372x |
| mixed | new JIT/interpreter | p99_script_render_ns | 0.2756 | 0.2002 | 1.364x | 1.309–1.420x |
| mixed | new JIT/interpreter | first_window_ns | 4.8264 | 4.9206 | 0.980x | 0.971–0.990x |
| mixed | new JIT/interpreter | hot_reload_ns | 0.3011 | 0.3037 | 0.990x | 0.984–0.997x |
