import os,json,subprocess,time,statistics,random,hashlib,platform
from pathlib import Path
P=Path(__file__).parent
bins={v:str(P/v) for v in ['baseline','candidate']}
meta={'cpu':2,'platform':platform.platform(),'baseline':'crates.io 0.12.6','candidate':'07535b14bf290c65f052bff19c49b89b316c0914','pairs':30,'warmup_processes':5,'renders_per_process':200,'binary_sha256':{v:hashlib.sha256(Path(b).read_bytes()).hexdigest() for v,b in bins.items()}}
(P/'metadata.json').write_text(json.dumps(meta,indent=2))
S=P/'samples'; S.mkdir(exist_ok=True)
for pair in range(-5,30):
    configs=[(v,m) for v in bins for m in ['interpreter','automatic']]
    if pair%2: configs.reverse()
    for workload in ['panel','compute','mixed']:
        for v,mode in configs:
            out=S/f'{pair}-{workload}-{v}-{mode}.json'
            env=dict(os.environ,GPUI_SHELL_JIT_SAMPLE=str(out),GPUI_SHELL_JIT_MODE=mode,GPUI_SHELL_JIT_PAIR=str(pair+5),GPUI_SHELL_JIT_WORKLOAD=workload)
            r=subprocess.run(['taskset','-c','2',bins[v],'tests::benchmark::emit_one_jit_acceptance_sample','--exact'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            if r.returncode: raise RuntimeError(f'{out}: {r.stdout}')
    print(f'completed pair {pair}',flush=True)
print('All samples completed',flush=True)
