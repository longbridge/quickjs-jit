"""Archive a completed frozen CFG candidate run and render its entire matrix."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

root = Path.cwd()
out = Path(Path('/tmp/quickjs-semantic-inline-induction-path').read_text())
paired = out / 'paired'
meta = json.loads((paired / 'metadata.json').read_text())
assert meta['status'] == 'complete', 'Partial runs cannot become acceptance results'
rows = json.loads((paired / 'summary.json').read_text())
workloads = (out / 'workloads.txt').read_text().split(',')
assert list(meta['scripts']) == workloads
assert len(workloads) == 27 and len(rows) == 162
by = {(r['workload'], r['variant'], r['mode']): r for r in rows}
assert len(by) == len(rows)
for workload in workloads:
    for variant, mode in meta['configs']:
        assert (workload, variant, mode) in by

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = json.loads((out / 'sources.json').read_text())
for path, expected in sources['source_files'].items():
    assert sha(out / 'source' / path) == expected, path
    assert sha(root / path) == expected, 'Working source changed after freeze: ' + path
for workload, expected in meta['scripts'].items():
    assert sha(out / 'source/benchmarks/scripts' / (workload + '.js')) == expected
for variant, path in meta['binaries'].items():
    assert sha(Path(path)) == meta['binary_sha256'][variant] == sources['binary_sha256'][variant]
assert sha(out / 'source.diff') == sources['source_diff_sha256']
expected_records = len(workloads) * len(meta['configs']) * (meta['pairs'] + meta['discarded_processes'])
assert expected_records == 2430
assert len(list(paired.glob('*.json'))) == expected_records + 2  # metadata and summary

stem = 'semantic-inline-induction-paired-arm64'
summary_path = root / 'benchmarks/results' / (stem + '.json')
archive_path = root / 'benchmarks/results' / (stem + '.tar.gz')
manifest_path = root / 'benchmarks/results' / (stem + '-manifest.json')
assert not any(path.exists() for path in [summary_path, archive_path, manifest_path])
shutil.copy2(paired / 'summary.json', summary_path)
stage = out / 'evidence'
stage.mkdir(exist_ok=False)
for directory in ['paired', 'source', 'interrupted', 'remaining']:
    shutil.copytree(out / directory, stage / directory)
with tarfile.open(root / 'benchmarks/results/semantic-inline-regions-paired-arm64.tar.gz', 'r:gz') as prior:
    prefix = 'semantic-inline-regions-paired-arm64/source/'
    for member in prior.getmembers():
        if member.isfile() and member.name.startswith(prefix):
            relative = Path(member.name[len(prefix):])
            assert not relative.is_absolute() and '..' not in relative.parts
            target = stage / 'previous-inline-source' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(prior.extractfile(member).read())
for name, expected in json.loads((out / 'previous-inline-sources.json').read_text())['source_files'].items():
    assert sha(stage / 'previous-inline-source' / name) == expected
shutil.copy2(Path(__file__), stage / 'archive-and-render.py')
for filename in ['sources.json', 'baseline-sources.json', 'source.diff', 'binaries.json',
                 'remaining-command.json', 'remaining.log', 'workloads.txt', 'paired-command.json', 'summarize-full.py', 'previous-inline-sources.json', 'full-summary.log', 'full.log', 'runtime-tests.log', 'clippy.log', 'build.log']:
    shutil.copy2(out / filename, stage / filename)
hashes = {str(path.relative_to(stage)): sha(path) for path in sorted(stage.rglob('*')) if path.is_file()}
(stage / 'SHA256SUMS.json').write_text(json.dumps(hashes, indent=2) + '\n')
with tarfile.open(archive_path, 'w:gz') as tar:
    tar.add(stage, arcname=stem)
with tarfile.open(archive_path, 'r:gz') as tar:
    for name, expected in hashes.items():
        assert hashlib.sha256(tar.extractfile(f'{stem}/{name}').read()).hexdigest() == expected, name

regressions = []
for workload in workloads:
    automatic = by[workload, 'candidate', 'automatic']
    comparison = automatic['comparisons']['baseline/automatic']
    if comparison['ci95'][1] < 1:
        regressions.append(dict(workload=workload, comparison=comparison,
            candidate_interpreter_vs_baseline_interpreter=by[workload, 'candidate', 'interpreter']['comparisons']['baseline/interpreter'],
            native_entry_range=automatic['native_entry_range']))
manifest = dict(runtime_base=sources['runtime_base'],
    candidate_source='archived source.diff and source/ tree',
    candidate_binary_sha256=meta['binary_sha256']['candidate'],
    quickjs='0.15.1, same candidate runtime with JIT detached',
    metadata=meta, archive=str(archive_path.relative_to(root)), archive_sha256=sha(archive_path),
    summary_sha256=sha(summary_path), verified_archived_files=len(hashes), process_records=expected_records,
    validation=sources['test_results'], statistically_significant_automatic_regressions=regressions,
    previous_inline_regressions=[dict(workload=w, comparison=by[w, 'candidate', 'automatic']['comparisons']['previous_inline/automatic']) for w in workloads if by[w, 'candidate', 'automatic']['comparisons']['previous_inline/automatic']['ci95'][1] < 1],
    architecture_gate='incomplete; effect-free inline replay only; general inline recovery, loop shape and Bun gates pending')
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')

def speed(value):
    estimate = value['speed']
    lo, hi = value['ci95']
    result = f'{estimate:.4f}x [{lo:.4f}, {hi:.4f}]'
    if lo <= 1 <= hi:
        result += f'; statistically tied ({(1-lo)*100:.2f}% slower to {(hi-1)*100:.2f}% faster)'
    return result

text = '''<!-- BEGIN JIT_MATRIX -->

**Complete 27-scenario macOS matrix, 2026-09-10–11: scalar loop synchronization and induction candidate.**
This frozen candidate amortizes polls only in admitted scalar regions, publishes
primitive locals at actual polls and deopt exits, and selects checked Int32
updates and comparisons from SSA proofs. Unknown calls and heap operations retain
the original polling policy. Mixed scalar loops poll every 64 header visits;
interrupt latency follows that bound. Raw Int32 loop block layout is preserved.
General inline-frame recovery, call-target guard hoisting, heap facts/LICM,
property forwarding/sinking, array range elimination and Bun gates remain pending.

The previous JIT column is revision `432afdf883c77d325f3a5d6a3275d1f893ccadad`,
frozen binary `30dd7e0ce72e05d2017f6f32335b0b17d8ee9c80715e40198d50e7856dce3682`.
The candidate is an uncommitted source snapshot based on that revision, binary
`1e7ab9858303c1e4258e2774acef72d6eeddcdc12074dcc6f72c1e666ad18aee`.
The original `023a220` baseline is also retained in JSON and interpreter controls.
Archived source snapshots and hashes identify measured revisions precisely.
QuickJS is version 0.15.1 with JIT detached in the candidate runtime.

'''
if regressions:
    text += 'The numeric-foundation no-regression gate remains **unmet**. Automatic runtime slowdowns relative to `023a220` with intervals entirely below parity occur in: '
    text += ', '.join('`' + item['workload'] + '`' for item in regressions) + '.\n'
    text += 'Interpreter controls are included below; these observations alone do not isolate the cause.\n\n'
else:
    text += 'No automatic-runtime slowdown has an interval entirely below parity in this run. Intervals crossing parity remain statistically tied; this does not establish the later architecture or Bun-performance gates.\n\n'
text += '''Timings are medians in **ms per ten workload calls**. Speed is reference
latency / candidate latency with paired geometric means and 95% confidence
intervals; values above 1x are faster. QuickJS uses the candidate binary with
JIT detached; quickjs-jit uses production automatic tiering; Bun uses defaults.
All scenarios, including losing, fallback-only and inconclusive results, remain
in the matrix.

| Workload | Previous JIT ms | QuickJS ms | Bun ms | quickjs-jit ms | JIT / previous speed [95% CI] | JIT / QuickJS speed [95% CI] | JIT / Bun speed [95% CI] |
| --- | ---: | ---: | ---: | ---: | --- | --- | --- |
'''
for workload in workloads:
    candidate = by[workload, 'candidate', 'automatic']
    previous = by[workload, 'previous_inline', 'automatic']
    interpreter = by[workload, 'candidate', 'interpreter']
    bun = by[workload, 'baseline', 'bun']
    comparisons = candidate['comparisons']
    text += (f"| {workload} | {previous['median_ns']/1e6:.6f} | {interpreter['median_ns']/1e6:.6f} | {bun['median_ns']/1e6:.6f} | {candidate['median_ns']/1e6:.6f} | "
             f"{speed(comparisons['previous_inline/automatic'])} | {speed(comparisons['candidate/interpreter'])} | {speed(comparisons['baseline/bun'])} |\n")
text += '''
Protocol `shared-js-fixed-warmup-v2`: one initial call, 64 ten-call warmup
batches, then one timed ten-call batch, with result consumption/checksum outside
timing. Scripts, inputs and driver match across engines. Every workload has
five discarded and 10 retained fresh processes per configuration; six
configurations alternate in reversed order. All 2,430 process records are
archived. The first segment completed 24 scenarios; temporary source-file loss
interrupted JSON codec. All source/binary hashes were restored and verified, and
the last three scenarios restarted from discarded warmup. Both segment metadata
and the interrupted samples/failure are archived. Bootstrap uses 10,000 paired percentile resamples, seed 20260909,
sorted indices 249/9749. Timing samples are not filtered by native readiness.

'''
text += f"Host: {meta['cpu_description']}; {meta['platform']}. Bun {meta['bun_version']}, default flags. "
text += f"Toolchain: {meta['rustc'].splitlines()[0]}; "
text += next((line for line in meta['rustc'].splitlines() if line.startswith('LLVM version:')), 'LLVM version recorded in manifest') + '.\n'
text += '''Release build, no CPU pinning; power policy not recorded. `host-compute`
measures the equivalent pure-JS render kernel, excluding GPUI allocation and
snapshots. No Linux, host-reload or throughput result is inferred.

Automatic native coverage and the paired interpreter control:

| Workload | Fixed-batch native entries (min–max) | Compilation quiet samples / 10 | Candidate / 023a220 interpreter speed [95% CI] |
| --- | ---: | ---: | --- |
'''
for workload in workloads:
    candidate = by[workload, 'candidate', 'automatic']
    lo, hi = candidate['native_entry_range']
    control = by[workload, 'candidate', 'interpreter']['comparisons']['baseline/interpreter']
    text += f"| {workload} | {lo}–{hi} | {candidate['compilation_quiet_samples']} | {speed(control)} |\n"
text += f'''
[All raw records and source/build inputs](benchmarks/results/{stem}.tar.gz),
[all configuration comparisons](benchmarks/results/{stem}.json),
[verified hashes, validation and provenance](benchmarks/results/{stem}-manifest.json),
and [remaining architecture and performance gates](docs/SEMANTIC_SSA_PROGRESS.md).

<!-- END JIT_MATRIX -->
'''
readme = root / 'README.md'
original = readme.read_text()
start = original.index('<!-- BEGIN JIT_MATRIX -->')
end = original.index('<!-- END JIT_MATRIX -->', start) + len('<!-- END JIT_MATRIX -->')
historical = original[start:end].replace('BEGIN JIT_MATRIX', 'BEGIN HISTORICAL_INLINE_JIT_MATRIX').replace('END JIT_MATRIX', 'END HISTORICAL_INLINE_JIT_MATRIX')
historical = historical.replace('**Complete 27-scenario', '**Historical 27-scenario', 1)
historical = historical.replace('Subsequent entry and numeric facts, semantic call operands, and bounded callee\nsnapshot retention are work in progress;\nits performance is not represented by this frozen matrix.\n', '')
heading_end = historical.index('**', historical.index('**') + 2) + 2
historical = historical[:heading_end] + '\nThese measurements apply only to the archived 432afdf bounded-inlining candidate and predate scalar poll/store/induction changes.\n' + historical[heading_end:]
historical = historical.replace('The numeric-foundation no-regression gate remains **unmet**.', 'The numeric-foundation no-regression gate was **unmet in this historical run**.', 1)
assert 'HISTORICAL_INLINE_JIT_MATRIX' not in original
readme.write_text(original[:start] + text + '\n' + historical + original[end:])
print(json.dumps(dict(archive=str(archive_path), verified_files=len(hashes), regressions=regressions), indent=2))
