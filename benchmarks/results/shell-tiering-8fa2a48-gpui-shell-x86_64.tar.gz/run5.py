import os, subprocess
from pathlib import Path
B = Path(__file__).parent
configs = [('0.12.9', 'automatic'), ('0.12.10', 'automatic'), ('fix-8fa2a48', 'automatic'), ('fix-8fa2a48', 'interpreter')]
out = B / os.environ.get('OUT', 'samples2'); out.mkdir(exist_ok=True)
for workload in ['panel', 'compute', 'mixed']:
    for pair in range(12):  # pairs 0-1 are discarded warmups
        order = configs if pair % 2 == 0 else configs[::-1]
        for ver, mode in order:
            target = out / f'{workload}-{pair}-{ver}-{mode}.json'
            env = dict(os.environ, GPUI_SHELL_JIT_SAMPLE=str(target), GPUI_SHELL_JIT_MODE=mode,
                       GPUI_SHELL_JIT_PAIR=str(pair), GPUI_SHELL_JIT_WORKLOAD=workload)
            subprocess.run(['taskset', '-c', os.environ.get('CPUS', '8'), str(B / 'bins' / f'shell-{ver}'),
                            'tests::benchmark::emit_one_jit_acceptance_sample', '--exact', '--test-threads=1'],
                           env=env, check=True, capture_output=True)
            assert target.exists(), target
        print(workload, pair, flush=True)
