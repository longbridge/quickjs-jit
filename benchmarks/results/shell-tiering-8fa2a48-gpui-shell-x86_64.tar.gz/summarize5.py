import json, math, random, statistics
from pathlib import Path
import sys; S=Path(sys.argv[1] if len(sys.argv)>1 else 'samples2'); rnd=random.Random(20260909)
def load(w,p,v,m): return json.loads((S/f'{w}-{p}-{v}-{m}.json').read_text())
def gm(xs):
    logs=[math.log(x) for x in xs]
    bs=sorted(math.exp(statistics.mean(rnd.choices(logs,k=len(logs)))) for _ in range(10000))
    return math.exp(statistics.mean(logs)), bs[249], bs[9749]
def fmt(t):
    s,lo,hi=t; tag='tied' if lo<=1<=hi else ('faster' if lo>1 else 'slower')
    return f"{s:.2f}x [{lo:.2f}, {hi:.2f}] {tag}"
C=[('0.12.9','automatic'),('0.12.10','automatic'),('fix-8fa2a48','automatic'),('fix-8fa2a48','interpreter')]
for w in ['panel','compute','mixed']:
    d={c:[load(w,p,*c) for p in range(2,12)] for c in C}
    ck={s['checksum'] for v in d.values() for s in v}
    fix=d[C[2]]
    for key,label in [('steady_state_ns','steady'),('p99_script_render_ns','P99')]:
        med={c:statistics.median(s[key] for s in v)/1000 for c,v in d.items()}
        print(f"{w:8} {label:6} interp {med[C[3]]:8.2f}  0.12.9 {med[C[0]]:8.2f}  0.12.10 {med[C[1]]:8.2f}  fix {med[C[2]]:8.2f} us | fix vs 0.12.9 {fmt(gm([a[key]/b[key] for a,b in zip(d[C[0]],fix)]))} | vs 0.12.10 {fmt(gm([a[key]/b[key] for a,b in zip(d[C[1]],fix)]))} | vs interp {fmt(gm([a[key]/b[key] for a,b in zip(d[C[3]],fix)]))}")
    print(f"         checksums agree: {len(ck)==1}; fix fallbacks {sum(s['fallback_count'] for s in fix)} deopts {sum(s['deopts'] for s in fix)}")
