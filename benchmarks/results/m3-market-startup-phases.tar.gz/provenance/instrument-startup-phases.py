from pathlib import Path
r=Path('/tmp/quickjs-market-measurements')
for kind,pointer in [('jit','/tmp/quickjs-market-host-path'),('upstream','/tmp/quickjs-market-upstream-host-path')]:
 p=Path(Path(pointer).read_text().strip())/'crates/shell/src/tests/benchmark.rs';s=p.read_text();(r/f'{kind}-before-startup-phases.rs').write_text(s)
 a='    let (runtime, mut context, object) = runtime_with_source(cx, &benchmark_source, interpreter);'
 b='''    let phase_started = Instant::now();
    let runtime = if interpreter {
        ShellRuntime::new_isolated_interpreter().expect("interpreter runtime")
    } else {
        ShellRuntime::new_isolated().expect("automatic JIT runtime")
    };
    let runtime_init_ns = phase_started.elapsed().as_nanos() as u64;
    let phase_started = Instant::now();
    cx.update(|cx| runtime.set_global(cx));
    let set_global_ns = phase_started.elapsed().as_nanos() as u64;
    let phase_started = Instant::now();
    let view_type = runtime.load_source("benchmark-view", &benchmark_source).expect("load");
    let load_source_ns = phase_started.elapsed().as_nanos() as u64;
    let phase_started = Instant::now();
    let window = cx.add_window(|_, _| Empty);
    let mut context = VisualTestContext::from_window(*window.deref(), cx);
    let window_ns = phase_started.elapsed().as_nanos() as u64;
    let phase_started = Instant::now();
    let object = context
        .update(|window, cx| runtime.instantiate(&view_type, window, cx))
        .expect("instantiate");
    let instantiate_ns = phase_started.elapsed().as_nanos() as u64;
    let phase_started = Instant::now();'''
 assert a in s;s=s.replace(a,b)
 a='    let first_window_ns = first_started.elapsed().as_nanos() as u64;';s=s.replace(a,'    let first_snapshot_ns = phase_started.elapsed().as_nanos() as u64;\n'+a)
 a='        "first_window_ns": first_window_ns,';assert a in s;s=s.replace(a,a+'\n        "startup_phases": { "runtime_init_ns": runtime_init_ns, "set_global_ns": set_global_ns, "load_source_ns": load_source_ns, "window_ns": window_ns, "instantiate_ns": instantiate_ns, "first_snapshot_ns": first_snapshot_ns },')
 p.write_text(s);(r/f'{kind}-startup-phases-benchmark.rs').write_text(s)
s=(r/'build_host.py').read_text().replace('/tmp/quickjs-market-host-path','/tmp/quickjs-market-upstream-host-path');(r/'build_upstream_diagnostic.py').write_text(s)
