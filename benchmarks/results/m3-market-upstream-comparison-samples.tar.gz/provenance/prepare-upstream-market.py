from pathlib import Path
import shutil,re
src=Path(Path('/tmp/quickjs-market-host-path').read_text());dst=src.with_name(src.name+'upstream')
shutil.copytree(src,dst,ignore=shutil.ignore_patterns('target','.git'),dirs_exist_ok=True)
Path('/tmp/quickjs-market-upstream-host-path').write_text(str(dst))
p=dst/'Cargo.toml';s=p.read_text();s=re.sub(r'\[patch.crates-io\][\s\S]*?(?=\[workspace.metadata.typos\])','',s);s=re.sub(r'\[patch\."https://github.com/longbridge/quickjs-jit"\][\s\S]*','',s);s=s.replace('quickjs-jit-sys = { opt-level = 3 }','rquickjs-sys = { opt-level = 3 }').replace('quickjs-jit-core = { opt-level = 3 }','rquickjs-core = { opt-level = 3 }');p.write_text(s)
p=dst/'crates/shell/Cargo.toml';s=p.read_text();s=s.replace('    "dep:rquickjs-jit",\n','');s=re.sub(r'rquickjs = \{ package = "quickjs-jit"[\s\S]*?\], optional = true \}', 'rquickjs = { version = "=0.12.2", features = ["macro", "loader"], optional = true }',s);s=re.sub(r'^rquickjs-jit = .*\n','',s,flags=re.M);p.write_text(s)
p=dst/'crates/shell/src/engine/quickjs/mod.rs';s=p.read_text().replace('use rquickjs_jit::{JitConfig, JitRuntime};','mod upstream_benchmark;\nuse upstream_benchmark as rquickjs_jit;\nuse rquickjs_jit::{JitConfig, JitRuntime};');p.write_text(s)
metrics=Path('jit/src/metrics.rs').read_text();metrics=metrics[:metrics.index('impl JitMetrics')].replace('//! Runtime-visible JIT metrics.','// Copied metric schema for the upstream interpreter benchmark; all counters are zero.')
stub=metrics+'''
impl JitMetrics { pub fn native_enabled(&self) -> bool { false } }
pub struct Jit;
impl Jit {
 pub fn is_suspended(&self) -> bool { false }
 pub fn suspend(&self) -> anyhow::Result<()> { Ok(()) }
 pub fn resume(&self) -> anyhow::Result<()> { Ok(()) }
}
pub struct JitConfig;
impl JitConfig { pub fn builder() -> Self { Self } pub fn build(self) -> anyhow::Result<Self> { Ok(self) } pub fn call_threshold(self, _: u32) -> Self { self } pub fn loop_threshold(self, _: u32) -> Self { self } }
pub struct JitRuntime(rquickjs::Runtime);
pub struct Builder;
impl Builder {
 pub fn config(self, _: JitConfig) -> Self { self }
 pub fn build(self) -> rquickjs::Result<JitRuntime> { rquickjs::Runtime::new().map(JitRuntime) }
 pub fn build_interpreter(self) -> rquickjs::Result<JitRuntime> { self.build() }
}
impl JitRuntime {
 pub fn builder() -> Builder { Builder }
 pub fn has_jit(&self) -> bool { false }
 pub fn jit(&self) -> &Jit { &Jit }
 pub fn metrics(&self) -> JitMetrics { JitMetrics::default() }
}
impl std::ops::Deref for JitRuntime { type Target = rquickjs::Runtime; fn deref(&self) -> &Self::Target { &self.0 } }
'''
(dst/'crates/shell/src/engine/quickjs/upstream_benchmark.rs').write_text(stub)
print(dst)
