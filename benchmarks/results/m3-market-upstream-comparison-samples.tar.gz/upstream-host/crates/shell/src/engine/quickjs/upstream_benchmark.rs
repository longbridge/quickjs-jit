// Copied metric schema for the upstream interpreter benchmark; all counters are zero.

/// Immutable metrics exposed by the no-op JIT backend.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct JitMetrics {
    native_enabled: bool,
    pub queued: u64,
    pub compiling: u64,
    pub compile_failures: u64,
    /// Worker compilations rejected because the bytecode is not supported.
    pub unsupported_opcode_failures: u64,
    /// Tier 1 compilations rejected by the closed semantic policy.
    pub tier1_rejections: u64,
    /// Worker compilations rejected by a compiler resource bound.
    pub resource_limit_failures: u64,
    pub compile_timeouts: u64,
    /// Worker compilations cancelled during shutdown or invalidation.
    pub cancelled_compilations: u64,
    /// Compiler panics contained by the background worker boundary.
    pub compiler_panics: u64,
    /// Worker results or artifacts rejected as structurally invalid.
    pub invalid_artifacts: u64,
    /// Valid compiler results that failed publication or cache installation.
    pub install_failures: u64,
    pub stale_results: u64,
    pub installed: u64,
    pub blacklisted: u64,
    pub retired: u64,
    pub queue_saturated: u64,
    pub completion_queue_saturated: u64,
    pub worker_queue_saturated: u64,
    pub resource_limit_rejections: u64,
    pub code_bytes: usize,
    pub metadata_bytes: usize,
    pub pending_worker_jobs: usize,
    pub pending_snapshot_bytes: usize,
    pub active_ir_bytes: usize,
    pub peak_compiler_bytes: usize,
    pub evicted: u64,
    pub native_entries: u64,
    /// Nonempty entry handles acquired from the backend, including OSR.
    /// Cached C entries execute again without increasing this counter.
    pub native_acquisitions: u64,
    pub native_exits: u64,
    pub native_fallbacks: u64,
    pub native_retries: u64,
    pub osr_entries: u64,
    pub osr_attempts: u64,
    pub osr_validated_successes: u64,
    pub osr_generated_retries: u64,
    pub hot_call_queues: u64,
    pub hot_loop_queues: u64,
    pub adaptive_neutral_queues: u64,
    pub adaptive_inputs_recorded: u64,
    pub adaptive_size_factor_disabled: u64,
    pub snapshot_requests: u64,
    pub osr_not_ready: u64,
    pub osr_map_misses: u64,
    pub osr_validation_failures: u64,
    pub tier2_entries: u64,
    pub tier2_guard_failures: u64,
    pub deopts: u64,
    pub deopt_materializations: u64,
    pub side_exits: u64,
    pub optimized_demotions: u64,
    /// Baseline artifacts unpublished after automatic profitability rejection.
    pub interpreter_demotions: u64,
    pub stable_path_compile_requests: u64,
    pub side_path_entries: u64,
    pub boxes_elided: u64,
    pub cse_eliminated: u64,
    pub dead_nodes_eliminated: u64,
    pub dependency_invalidations: u64,
    /// Functions kept in the interpreter because every native tier would
    /// pay the generic call bridge on each call without a loop to amortize it.
    pub generic_call_rejections: u64,
    pub profitability_evaluations: u64,
    pub profitability_approved: u64,
    pub profitability_rejected: u64,
    pub benefit_recordings: u64,
    pub measured_benefit_ns: u64,
    pub compile_ns: u64,
    pub install_ns: u64,
}


impl JitMetrics { pub fn native_enabled(&self) -> bool { false } }
pub struct Jit;
impl Jit {
 pub fn is_suspended(&self) -> bool { false }
 pub fn suspend(&self) -> anyhow::Result<()> { Ok(()) }
 pub fn resume(&self) -> anyhow::Result<()> { Ok(()) }
}
pub struct JitConfig;
impl JitConfig { pub fn builder() -> Self { Self } pub fn build(self) -> anyhow::Result<Self> { Ok(self) } pub fn call_threshold(self, _: u32) -> Self { self } pub fn loop_threshold(self, _: u32) -> Self { self } }
pub struct JitRuntime(rquickjs::Runtime);
pub struct Builder;
impl Builder {
 pub fn config(self, _: JitConfig) -> Self { self }
 pub fn build(self) -> rquickjs::Result<JitRuntime> { rquickjs::Runtime::new().map(JitRuntime) }
 pub fn build_interpreter(self) -> rquickjs::Result<JitRuntime> { self.build() }
}
impl JitRuntime {
 pub fn builder() -> Builder { Builder }
 pub fn has_jit(&self) -> bool { false }
 pub fn jit(&self) -> &Jit { &Jit }
 pub fn metrics(&self) -> JitMetrics { JitMetrics::default() }
}
impl std::ops::Deref for JitRuntime { type Target = rquickjs::Runtime; fn deref(&self) -> &Self::Target { &self.0 } }
