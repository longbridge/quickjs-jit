from pathlib import Path
import json,subprocess,collections,re
r=Path('/tmp/quickjs-market-measurements');x=json.loads((r/'mixed-cold-profile.json').read_text());t=max(x['threads'],key=lambda t:t['samples']['length']);f=t['frameTable'];fn=t['funcTable'];resources=t['resourceTable'];libidx=next(i for i,l in enumerate(x['libs']) if l['name']=='cold-probes-profile');indices=[];addresses=[]
for i in range(f['length']):
 resource=fn['resource'][f['func'][i]]
 if resource>=0 and resources['lib'][resource]==libidx:
  indices.append(i);addresses.append(hex(f['address'][i]+0x100000000))
names={}
for k in range(0,len(indices),150):
 out=subprocess.check_output(['atos','-arch','arm64','-o',str(r/'cold-probes-profile'),'-l','0x100000000',*addresses[k:k+150]],text=True).splitlines()
 for i,n in zip(indices[k:k+150],out):names[i]=n.split(' (in ')[0]
selfs=collections.Counter();inclusive=collections.Counter();stack=t['stackTable']
for s in t['samples']['stack']:
 if s is None:continue
 seen=set();first=True
 while s is not None:
  frame=stack['frame'][s];n=names.get(frame,'other/JIT')
  if first:selfs[n]+=1;first=False
  seen.add(n);s=stack['prefix'][s]
 inclusive.update(seen)
result={'samples':t['samples']['length'],'self':selfs.most_common(45),'inclusive':inclusive.most_common(45)}
(r/'mixed-cold-profile-attribution.json').write_text(json.dumps(result,indent=2));(r/'mixed-cold-profile-symbols.json').write_text(json.dumps(names,indent=2));print(json.dumps({'samples':result['samples'],'self':result['self'][:22]},indent=2))
