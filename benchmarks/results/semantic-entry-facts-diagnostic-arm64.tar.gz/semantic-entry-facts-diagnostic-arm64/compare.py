from pathlib import Path
import json,math,statistics,random
p=Path(Path('/tmp/quickjs-semantic-entry-facts-path').read_text())/'diagnostic'
rows=json.loads((p/'summary.json').read_text());result=[]
for r in rows:
 if (r['variant'],r['mode'])!=('candidate','automatic'):continue
 w=r['workload']; rng=random.Random(20260909)
 ratios=[json.loads((p/f'{w}-{i}-previous_bitwise-automatic.json').read_text())['elapsed_ns']/json.loads((p/f'{w}-{i}-candidate-automatic.json').read_text())['elapsed_ns'] for i in range(10)]
 logs=list(map(math.log,ratios));bs=sorted(math.exp(statistics.mean(rng.choices(logs,k=10))) for _ in range(10000))
 c=r['comparisons'];result.append(dict(workload=w,baseline=c['baseline/automatic'],previous_bitwise=dict(speed=math.exp(statistics.mean(logs)),ci95=[bs[249],bs[9749]]),QuickJS=c['candidate/interpreter'],Bun=c['baseline/bun']))
(p/'comparisons.json').write_text(json.dumps(result,indent=2)+'\n')
